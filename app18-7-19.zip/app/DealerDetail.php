<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class dealerDetail extends Model
{
    //
     protected $table = 'dealer_detail';

   

}
