<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class userRatings extends Model
{
    //
     protected $table = 'user_ratings';

   

}
