<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SubscriptionPlans extends Model
{
    //

     protected $table = 'subscription_plans';

    

    
}
