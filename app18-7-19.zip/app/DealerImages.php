<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class dealerImages extends Model
{
    //
     protected $table = 'dealer_images';

   

}
