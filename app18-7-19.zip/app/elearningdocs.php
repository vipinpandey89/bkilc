<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class elearningdocs extends Model
{
    //
}
