<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class dealerPost extends Model
{
    //
     protected $table = 'dealer_post';

   

}
