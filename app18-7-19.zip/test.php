<?php
php_info();

