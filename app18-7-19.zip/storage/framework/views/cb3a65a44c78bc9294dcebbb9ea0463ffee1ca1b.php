<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>

<div id="page-wrapper">
			<div class="main-page">
			<div class="col_3">
        	
        	<div class="col-md-3 widget widget1">
        		<div class="r3_counter_box">
                    <i class="pull-left fa fa-laptop user1 icon-rounded"></i>
                    <div class="stats">
                      <h5><strong><?php echo e($totals['Promoter']); ?></strong></h5>
                      <span>Promotori totali</span>
                    </div>
                </div>
        	</div>
        	<div class="col-md-3 widget widget1">
        		<div class="r3_counter_box">
                    <i class="pull-left fa fa-money user2 icon-rounded"></i>
                    <div class="stats">
                      <h5><strong><?php echo e($totals['Affiliati']); ?></strong></h5>
                      <span>Affiliati totali</span>
                    </div>
                </div>
        	</div>
        	<div class="col-md-3 widget widget1">
        		<div class="r3_counter_box">
                    <i class="pull-left fa fa-pie-chart dollar1 icon-rounded"></i>
                    <div class="stats">
                      <h5><strong><?php echo e($totals['Utenti card']); ?></strong></h5>
                      <span>Totale utenti di carte</span>
                    </div>
                </div>
        	 </div>
        	<div class="col-md-3 widget widget1">
        		<div class="r3_counter_box">
                    <i class="pull-left fa fa-dollar icon-rounded"></i>
                    <div class="stats">
                      <h5><strong>$<?php echo e($totals['totalpayment']); ?></strong></h5>
                      <span>Pagamenti totali</span>
                    </div>
                </div>
        	</div>
        	<div class="clearfix"> </div>
		</div>
		
		<div class="row-one widgettable">
		</div>
				
				<div class="charts">
					<div class="col-md-4 charts-grids widget">						
						<div id="piechart" style="width: 400px; height: 295;"></div>						
					</div>
					
					<div class="col-md-4 charts-grids widget states-mdl">						
						 <div id="columnchart_material" style="width: 800px; height: 295px;"></div>
					</div>
			
					<div class="clearfix"> </div>
				</div>		

				<div class="charts">
					
					
					<div class="col-md-12">						
						 <div id="chart_div" style="width: 950px; height: 295px;"></div>
					</div>
			
					<div class="clearfix"> </div>
				</div>			
           </div>
   </div>
<?php $__env->stopSection(); ?>

  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<!-- vertical graph -->


   <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

     
      var alldata= '<?php echo $data;?>';

      	var obj= JSON.parse(alldata);

      var output= [];
      	$.each( obj, function( key, value ) {
  						output.push(value);
				});
      	//console.log(output);
      		

      function drawChart() {
        var data = google.visualization.arrayToDataTable(output);

        var options = {
          chart: {
            title: 'Performance Aziendale',
            subtitle: ' Carte vendute, Upgrade, and Affiliati: 2019',
          }
        };

        var chart = new google.charts.Bar(document.getElementById('columnchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
    </script>

<!-- end here-->

<!--pie graph-->

<script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);



      var pichart= '<?php echo $pichart;?>';

        var objpichart= JSON.parse(pichart);

      var outputpichart= [];
        $.each( objpichart, function( key, value ) {
              outputpichart.push(value);
        });
        

      function drawChart() {

        var data = google.visualization.arrayToDataTable(outputpichart);

        var options = {
          title: 'Performance ultimo anno'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>

<!-- end here--->


<!-- line char-->

<script type="text/javascript">
	google.charts.load('current', {packages: ['corechart', 'line']});
google.charts.setOnLoadCallback(drawBackgroundColor);

function drawBackgroundColor() {
      var data = new google.visualization.DataTable();
      data.addColumn('number', 'X');
      data.addColumn('number', 'Pagamenti');


      var paymentdata= '<?php echo $paymentdata;?>';

      	var obj1= JSON.parse(paymentdata);

       

      var output1= [];

      	$.each( obj1, function( key1, value1 ) {

  						output1.push(value1);
              //console.log(value1);
				});
				
      	
      
      console.log(output1);
      data.addRows(output1);

      //data.addRows([0,1],[1,10]);

      var options = {
        hAxis: {
          title: 'Mesi'
        },
        vAxis: {
          title: 'Pagamenti'
        },
        backgroundColor: '#f1f8e9'
      };

      var chart = new google.visualization.LineChart(document.getElementById('chart_div'));
      chart.draw(data, options);
    }
</script>
<!-- end here-->


<?php echo $__env->make('administrator.layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>