<?php $__env->startSection('title','UserList'); ?>

<?php $__env->startSection('content'); ?>

		<div id="page-wrapper">

			<div class="main-page">

				<div class="forms">					

					<div class="form-grids row widget-shadow" data-example-id="basic-forms"> 

						<div class="form-title">

							<h4>Gestione del Promotore degli Affiliati</h4>

						</div>

						<div class="form-body">

							<form method="post" id="demo-form" data-parsley-validate> 

							<input type="hidden" value="<?php echo e($affid); ?>" name="aff_id" />
							<div class="form-group <?php echo e($errors->has('promotor') ? ' has-error' : ''); ?>">

								 <label for="promotor">Select Promotor</label>

								 <select class="form-control" name="promotor">

								 	<option value="">Select Promotor</option>
									<?php $__currentLoopData = $allPromotors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allPromotorsVal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($allPromotorsVal->id); ?>" ><?php echo e($allPromotorsVal->name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									
									
									

								 </select> 

										



								  <?php if($errors->has('promotor')): ?>

                                    <span class="help-block">

                                        <strong><?php echo e($errors->first('promotor')); ?></strong>

                                    </span>

                                <?php endif; ?>



							</div>
							
							



								  <?php echo e(csrf_field()); ?>




							  <button type="submit" name="addbutton" class="btn btn-default">Aggiornare</button> 

							</form> 

						</div>

					</div>										

				</div>

			</div>

		</div>



<!--<script type="text/javascript">

$(function () {

  $('#demo-form').parsley().on('field:validated', function() {

    var ok = $('.parsley-error').length === 0;

    $('.bs-callout-info').toggleClass('hidden', !ok);

    $('.bs-callout-warning').toggleClass('hidden', ok);

  })



});



</script>	-->	

		<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrator.layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>