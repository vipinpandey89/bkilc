<?php $__env->startSection('content'); ?>
 <div id="page-wrapper" >
            <div id="page-inner">
                
               
               <div class="row">
                <div class="col-md-12">
                    <!-- Form Elements -->
                    <div class="panel panel-default">
                      <!--  <strong>Completa il tuo profilo per ottenere la carta Bklic e la lettera di conferma</strong> -->
                   
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-6">                                  
                                    
                             <?php if(Session::has('success')): ?>
                               <div class="alert alert-success alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button> 
                                        <strong><?php echo e(Session::get('success')); ?></strong>
                                </div>
                             <?php endif; ?>



                                    <form role="form" method="post" id="demo-form" data-parsley-validate enctype="multipart/form-data">
                                         <?php echo e(csrf_field()); ?>



                                         <!--<div class="form-group">
                                            <label>ID Personale</label>
                                           <input id="name" type="text" class="form-control" value="<?php echo e(!empty($userProfile)?$userProfile->id:old('name')); ?>" required autofocus  readonly="">
                                         
                                        </div>


                                        <div class="form-group ">
                                            <label>Punteggio</label>
                                           <input id="name" type="text" class="form-control"  value="<?php echo e(!empty($userProfile)?'0':old('name')); ?>" required autofocus  readonly="">

                                           
                                        </div>

                                         <div class="form-group">
                                            <label>Bilancio</label>
                                           <input id="name" type="text" class="form-control"  value="<?php echo e(!empty($userProfile)?'0':old('name')); ?>" required autofocus  readonly="">

                                          
                                        </div>-->



                                        <div class="form-group <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                            <label>Nome <span style="color: red;">*</span></label>
                                           <input id="name" type="text" class="form-control" name="name" value="<?php echo e(!empty($userProfile->name)?$userProfile->name:old('name')); ?>" required autofocus maxlength="30">

                                            <?php if($errors->has('name')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group form-group<?php echo e($errors->has('userName') ? ' has-error' : ''); ?>">
                                             <label for="userName">Cognome <span style="color: red;">*</span></label>

                            
                                            <input id="userName" type="text" class="form-control" name="userName" value="<?php echo e(!empty($userProfile->userName)?$userProfile->userName: old('userName')); ?>" required autofocus maxlength="30">

                                            <?php if($errors->has('userName')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('userName')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>


                                        <?php 
                                         $date= strtotime('+1 years',strtotime($userProfile->created_at));  ?>


                                         <!--<div class="form-group form-group">
                                             <label for="userName" class="col-md-4 control-label">Data Registrazione</label>                            
                                            <input id="userName" type="text" class="form-control" value="<?php echo e(!empty($userProfile)?date('m-d-Y',strtotime($userProfile->created_at)): old('userName')); ?>" required autofocus readonly="">
                                          
                                        </div>


                                        <div class="form-group form-group">
                                             <label for="userName" class="col-md-4 control-label">Scadenza</label>
                            
                                            <input id="userName" type="text" class="form-control" value="<?php echo e(!empty($userProfile)?date('m-d-Y',$date): old('userName')); ?>" required autofocus  readonly="">
                                          
                                        </div>



                                         <div class="form-group form-group<?php echo e($errors->has('referralCode') ? ' has-error' : ''); ?>">
                                            <label for="referralCode" class="col-md-4 control-label">Codice di riferimento</label>
                                       
                                              <input id="referralCode" type="text" class="form-control" name="referralCode" value="<?php echo e(!empty($userProfile)?$userProfile->referralCode:old('referralCode')); ?>" readonly=""  autofocus>

                                            <?php if($errors->has('referralCode')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('referralCode')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>-->

                                         <div class="form-group form-group<?php echo e($errors->has('telephoneNumber') ? ' has-error' : ''); ?>">
                                              <label for="telephoneNumber">Telefono <span style="color: red;">*</span></label>

                                
                                                <input id="telephoneNumber" type="text" class="form-control" name="telephoneNumber" value="<?php echo e(!empty($userProfile)?$userProfile->telephoneNumber: old('telephoneNumber')); ?>" required autofocus>

                                                <?php if($errors->has('telephoneNumber')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('telephoneNumber')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                        </div>

                                       


                                         <div class="form-group form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                              <label for="email">E-mail <span style="color: red;">*</span></label>

                                      
                                            <input id="email" type="email" class="form-control" name="email" value="<?php echo e(!empty($userProfile)?$userProfile->email: old('email')); ?>" readonly="" required>

                                            <?php if($errors->has('email')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>


                                        <!--<div class="form-group form-group<?php echo e($errors->has('dob') ? ' has-error' : ''); ?>">
                                              <label for="dob" class="col-md-4 control-label">Nata/o a</label>
                                      
                                            <input id="dob" type="date" class="form-control" name="dob" value="<?php echo e(!empty($userProfile)?$userProfile->dob: old('dob')); ?>" required>

                                            <?php if($errors->has('dob')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('dob')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>-->

                                         <div class="form-group form-group<?php echo e($errors->has('resiaddress') ? ' has-error' : ''); ?>">
                                              <label for="resiaddress">Indirizzo <span style="color: red;">*</span></label>
                                      
                                            <input id="resiaddress" type="text" class="form-control" name="resiaddress" value="<?php echo e(!empty($userProfile)?$userProfile->resiaddress: old('resiaddress')); ?>" required>

                                            <?php if($errors->has('resiaddress')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('resiaddress')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>

                                         <div class="form-group form-group<?php echo e($errors->has('region') ? ' has-error' : ''); ?>">
                                              <label for="region">Città <span style="color: red;">*</span></label>
                                      
                                            <input id="region" type="text" class="form-control" name="region" value="<?php echo e(!empty($userProfile)?$userProfile->region: old('region')); ?>" required>

                                            <?php if($errors->has('region')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('region')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>

                                          <div class="form-group form-group<?php echo e($errors->has('postalCode') ? ' has-error' : ''); ?>">
                                             <label for="postalCode">Cap <span style="color: red;">*</span></label>

                                
                                            <input id="postalCode" type="text" class="form-control" name="postalCode" value="<?php echo e(!empty($userProfile)?$userProfile->postalCode:old('postalCode')); ?>" required autofocus>

                                            <?php if($errors->has('postalCode')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('postalCode')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>


                                         <!--<div class="form-group form-group<?php echo e($errors->has('streat') ? ' has-error' : ''); ?>">
                                              <label for="streat" class="col-md-4 control-label">Via</label>
                                      
                                            <input id="streat" type="text" class="form-control" name="streat" value="<?php echo e(!empty($userProfile)?$userProfile->streat: old('streat')); ?>" required>

                                            <?php if($errors->has('streat')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('streat')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group form-group<?php echo e($errors->has('Fcode') ? ' has-error' : ''); ?>">
                                              <label for="Fcode" class="col-md-4 control-label">Cod. Fiscale</label>
                                      
                                            <input id="Fcode" type="text" class="form-control" name="Fcode" value="<?php echo e(!empty($userProfile)?$userProfile->fcode: old('Fcode')); ?>" required>

                                            <?php if($errors->has('Fcode')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('Fcode')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>

                                         <div class="form-group form-group<?php echo e($errors->has('pariva') ? ' has-error' : ''); ?>">
                                              <label for="pariva" class="col-md-4 control-label">Part. I.V.A</label>
                                      
                                            <input id="pariva" type="text" class="form-control" name="pariva" value="<?php echo e(!empty($userProfile)?$userProfile->pariva: old('pariva')); ?>" required>

                                            <?php if($errors->has('pariva')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('pariva')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>  -->


                                         <!--<div class="form-group form-group<?php echo e($errors->has('business_name') ? ' has-error' : ''); ?>">
                                              <label for="business_name" class="col-md-4 control-label">Ragione Sociale</label>
                                      
                                            <input id="business_name" type="text" class="form-control" name="business_name" value="<?php echo e(!empty($userProfile)?$userProfile->business_name: old('business_name')); ?>" required>

                                            <?php if($errors->has('business_name')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('business_name')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>  -->


                                          <!--<div class="form-group form-group<?php echo e($errors->has('IBAN') ? ' has-error' : ''); ?>">
                                              <label for="IBAN" class="col-md-4 control-label">IBAN</label>
                                      
                                            <input id="IBAN" type="text" class="form-control" name="IBAN" value="<?php echo e(!empty($userProfile)?$userProfile->iban: old('IBAN')); ?>" required>

                                            <?php if($errors->has('IBAN')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('IBAN')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>  


                                         <div class="form-group form-group<?php echo e($errors->has('bank') ? ' has-error' : ''); ?>">
                                              <label for="bank" class="col-md-4 control-label">Banca</label>
                                      
                                            <input id="bank" type="text" class="form-control" name="bank" value="<?php echo e(!empty($userProfile)?$userProfile->bank: old('bank')); ?>" required>

                                            <?php if($errors->has('bank')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('bank')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>  

                                          <div class="form-group form-group<?php echo e($errors->has('Paypal') ? ' has-error' : ''); ?>">
                                              <label for="Paypal" class="col-md-4 control-label">Paypal</label>
                                      
                                            <input id="Paypal" type="text" class="form-control" name="Paypal" value="<?php echo e(!empty($userProfile)?$userProfile->paypal: old('Paypal')); ?>" required>

                                            <?php if($errors->has('Paypal')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('Paypal')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>  -->
                                        
										
						<!--<div class="form-group<?php echo e($errors->has('category') ? ' has-error' : ''); ?>">
                            <label for="category" class="col-md-4 control-label">Categoria</label>

                           
								<select class="form-control" id="category" name="category">
									<option value="">Seleziona categoria</option>
                                    <option value="1" <?php if(!empty($userProfile)){ if($userProfile->category == 1){ echo 'selected'; }} ?>>Test1</option>
                                    <option value="2" <?php if(!empty($userProfile)){ if($userProfile->category == 2){ echo 'selected'; }} ?>>Test2</option>
                                    <option value="3" <?php if(!empty($userProfile)){ if($userProfile->category == 3){ echo 'selected'; }} ?>>Test3</option>
                                    <option value="4" <?php if(!empty($userProfile)){ if($userProfile->category == 4){ echo 'selected'; }} ?>>Test4</option>
								</select>

                                <?php if($errors->has('category')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('category')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            
                        </div>
						
						<div class="form-group<?php echo e($errors->has('subcategory') ? ' has-error' : ''); ?>">
                            <label for="subcategory" class="col-md-4 control-label">Sottocategoria</label>

                            
								<select class="form-control" id="subcategory" name="subcategory">
									<option value="">Seleziona categoria</option>
                                    <option value="1" <?php if(!empty($userProfile)){ if($userProfile->sub_category == 1){ echo 'selected'; }} ?>>Test1</option>
                                    <option value="2" <?php if(!empty($userProfile)){ if($userProfile->sub_category == 2){ echo 'selected'; }} ?>>Test2</option>
                                    <option value="3" <?php if(!empty($userProfile)){ if($userProfile->sub_category == 3){ echo 'selected'; }} ?>>Test3</option>
                                    <option value="4" <?php if(!empty($userProfile)){ if($userProfile->sub_category == 4){ echo 'selected'; }} ?>>Test4</option>
								</select>

                                <?php if($errors->has('subcategory')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('subcategory')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            
                        </div> -->
										
										<!--<div class="form-group form-group<?php echo e($errors->has('discount_amount') ? ' has-error' : ''); ?>">
                                              <label for="discount_amount" class="col-md-4 control-label">Totale sconto</label>
                                      
                                            <input id="discount_amount" type="text" class="form-control" name="discount_amount" value="<?php echo e(!empty($userProfile)?$userProfile->discount_amount: old('discount_amount')); ?>" required>

                                            <?php if($errors->has('discount_amount')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('discount_amount')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div> -->



                                        <!--<div class="form-group form-group<?php echo e($errors->has('profileImage') ? ' has-error' : ''); ?>">

                                              <label for="pariva" class="col-md-4 control-label">Immagine del profilo</label>   

                                            <input id="profileImage" type="file" class="form-control" name="profileImage" >

                                             <input type="hidden" name="old_file" value="<?php echo e(!empty($userProfile->profileimage)?$userProfile->profileimage:''); ?>"> 
                                            <?php if(!empty($userProfile->profileimage)): ?>
                                            <img src="<?php echo e(url('images/profile_images/'.$userProfile->profileimage)); ?>" style="height: 82px;width: 89px;">
                                            <?php endif; ?>

                                            <?php if($errors->has('profileImage')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('profileImage')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>-->
                                        
                                       <!-- <div class="form-group form-group<?php echo e($errors->has('logoImage') ? ' has-error' : ''); ?>">

                                              <label for="pariva" class="col-md-4 control-label">Carica logo</label>   

                                            <input id="profileImage" type="file" class="form-control" name="logoImage" >

                                             <input type="hidden" name="old_logo" value="<?php echo e(!empty($userProfile->logo)?$userProfile->logo:''); ?>"> 
                                            <?php if(!empty($userProfile->logo)): ?>
                                            <img src="<?php echo e(url('dealer_logos/'.$userProfile->logo)); ?>" style="height: 82px;width: 89px;">
                                            <?php endif; ?>

                                            <?php if($errors->has('logoImage')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('logoImage')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>-->


                                           <div class="form-group form-group<?php echo e($errors->has('pariva') ? ' has-error' : ''); ?>">
                                              <label for="pariva">Part. I.V.A <span style="color: red;">*</span></label>
                                      
                                            <input id="pariva" type="text" class="form-control" name="pariva" value="<?php echo e(!empty($userProfile)?$userProfile->pariva: old('pariva')); ?>" required>

                                            <?php if($errors->has('pariva')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('pariva')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div> 

                                        
                                        <button type="submit" name="updateprofile" class="btn btn-default">Conferma modifiche</button>                                     
                                    </form>
                                  
                                </div>
                               <?php /* ?> <div class="col-md-6"> 

                                        <!--<div class="col-md-2">    -->      
                                            @if(!empty($userProfile->qr_code))    
                                                  <img src="{{url('/'.$userProfile->qr_code)}}">
                                             @endif 
                                          <!-- </div>-->
                                </div>


                                 <div class="col-md-6"> 

                                  
                                     @if($userProfile->is_profile_complete =='1')    
                                        <a href="{{url('/images/bklic_card.pdf')}}" download title="Bklic Card">
                                            <img src="{{url('/images/bklic_card.jpg')}}" alt="W3Schools" style="width: 409px;  margin-left: 39px; height: 174px;  margin-top: 37px;">
                                         </a>
                                           @endif 
                                </div>


                                 <div class="col-md-6"> 

                                    @if($userProfile->is_profile_complete =='1')    
                                      <a href="{{url('/images/bklic_letter.pdf')}}" download title="Comfirmation Letter">
                                         <img src="{{url('/images/bklic_letter.jpg')}}" alt="W3Schools" style="width: 308px;  margin-left: 39px; height: 174px;  margin-top: 37px;">
                                       </a>
                                      @endif 
                                </div> <?php */ ?>
                            </div>
                        </div>
                    </div>                   
                </div>
            </div>              
    </div>
            
            </div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>


<script type="text/javascript">
$(function () {
  $('#demo-form').parsley().on('field:validated', function() {
    var ok = $('.parsley-error').length === 0;
    $('.bs-callout-info').toggleClass('hidden', !ok);
    $('.bs-callout-warning').toggleClass('hidden', ok);
  })

});




var placeSearch, autocomplete;

var componentForm = {
  street_number: 'short_name',
  route: 'long_name',
  locality: 'long_name',
  administrative_area_level_1: 'short_name',
  country: 'long_name',
  postal_code: 'short_name'
};

      /**
       * Google Places auto-complete
       */
      function initMap() {
        var input = document.getElementById('resiaddress');
        var options = {
          types: ["geocode"]
        };
        autocomplete = new google.maps.places.Autocomplete(input, options);

        addAutocompleteListener(autocomplete, "#resiaddress", true);
      }

      function addAutocompleteListener(autocomplete, elm, target) {
        autocomplete.addListener('place_changed', function() {
          var place = autocomplete.getPlace();
          var address = "";
           console.log(place.address_components);
          var city_name = country_code = territory_code = postal_code = "" ;
          var country_name = territory_name = "";
          place.address_components.forEach(function(obj) {
            // Sublocality
            if (obj.types.indexOf("neighborhood") != -1) {
              jQuery(elm).val(jQuery(elm).val() + obj.long_name + ", ");
              city_name = obj.long_name;
        jQuery("#region").val(city_name);
            }
      
      if (obj.types.indexOf("postal_code") != -1) {
              jQuery(elm).val(jQuery(elm).val() + obj.long_name + ", ");
              postal_code = obj.long_name;
        console.log(postal_code);
        jQuery("#postalCode").val(postal_code);
            }
      
            if (obj.types.indexOf("sublocality") != -1 && city_name == "") {
              jQuery(elm).val(jQuery(elm).val() + obj.long_name + ", ");
              city_name = obj.long_name;
        jQuery("#region").val(city_name);
            }
            if (obj.types.indexOf("administrative_area_level_3") != -1 && city_name == "") {
              jQuery(elm).val(jQuery(elm).val() + obj.long_name + ", ");
              city_name = obj.long_name;
        jQuery("#region").val(city_name);
            }
            // City
            if (obj.types.indexOf("locality") != -1 && city_name == "") {
              jQuery(elm).val(jQuery(elm).val() + obj.long_name + ", ");
              city_name = obj.long_name;
        jQuery("#region").val(city_name);
            }
            // Territory
            if (obj.types.indexOf("administrative_area_level_1") != -1 ) {
              jQuery(elm).val(jQuery(elm).val() + obj.short_name + ", ");
              territory_code = obj.short_name;
              territory_name = obj.long_name;
            }
            // Country
            if (obj.types.indexOf("country") != -1) {
              jQuery(elm).val(jQuery(elm).val() + obj.long_name);
              country_code = obj.short_name;
              country_name = obj.long_name;
            }
          })
          if (target)
          {
            //target_google_ville(city_name, territory_code, country_code, territory_name, country_name);
          }
          // jQuery("#shipping_form_street_address").val(address);
        });
      }



</script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAThYtCdyyeiqogil0eUFqq2W8tNhyWTUU&libraries=places&callback=initMap"></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('Affiliatese.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>