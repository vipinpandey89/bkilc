-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 04, 2019 at 11:05 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 5.6.37

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bklic`
--

-- --------------------------------------------------------

--
-- Table structure for table `affiliate_category`
--

CREATE TABLE `affiliate_category` (
  `id` int(10) NOT NULL,
  `title` varchar(200) DEFAULT NULL,
  `parent_id` int(10) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `affiliate_category`
--

INSERT INTO `affiliate_category` (`id`, `title`, `parent_id`, `created_at`, `updated_at`) VALUES
(1, 'test', 0, '2019-05-29 12:30:03', '2019-05-29 12:30:03'),
(2, 'Test2', 0, '2019-06-03 09:20:41', '2019-06-03 09:20:41');

-- --------------------------------------------------------

--
-- Table structure for table `billing_detail`
--

CREATE TABLE `billing_detail` (
  `id` int(20) NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `checkout_id` int(10) DEFAULT NULL,
  `paid_id` int(30) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` varchar(250) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `zip` varchar(30) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `billing_detail`
--

INSERT INTO `billing_detail` (`id`, `user_id`, `checkout_id`, `paid_id`, `name`, `email`, `address`, `city`, `state`, `zip`, `created_at`, `updated_at`) VALUES
(26, 54, NULL, 26, 'mukesh', 'mukesh', 'laxmi nagar', 'delhi', 'delhi', '110052', '2019-05-13 11:46:22', '2019-05-13 11:46:22');

-- --------------------------------------------------------

--
-- Table structure for table `bonus_management`
--

CREATE TABLE `bonus_management` (
  `id` int(10) NOT NULL,
  `user_id` int(90) DEFAULT NULL,
  `promoter_percentage` varchar(20) DEFAULT NULL,
  `bklic_profit` varchar(10) DEFAULT NULL,
  `date_apply` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bonus_management`
--

INSERT INTO `bonus_management` (`id`, `user_id`, `promoter_percentage`, `bklic_profit`, `date_apply`, `created_at`, `updated_at`) VALUES
(1, 59, '5', '1', NULL, '2019-05-29 11:53:25', '2019-05-29 11:53:25');

-- --------------------------------------------------------

--
-- Table structure for table `calendar_management`
--

CREATE TABLE `calendar_management` (
  `id` int(10) NOT NULL,
  `title` varchar(250) DEFAULT NULL,
  `description` text,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `calendar_management`
--

INSERT INTO `calendar_management` (`id`, `title`, `description`, `start_time`, `end_time`, `created_at`, `updated_at`) VALUES
(1, 'Success Story', '<p>fdffass</p>', '2019-05-23 01:00:00', '2019-05-25 01:00:00', '2019-05-14 12:13:07', '2019-05-14 12:13:07'),
(2, 'Create Test Event', '<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in</p>', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-05-21 07:53:09', '2019-05-21 07:53:09'),
(3, 'dfsdafsa', '<p>sdfsafsdafsdafsda</p>', '2019-05-31 21:00:00', '2019-05-31 22:00:00', '2019-05-31 13:11:14', '2019-05-31 13:11:14');

-- --------------------------------------------------------

--
-- Table structure for table `checkout`
--

CREATE TABLE `checkout` (
  `id` int(10) NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `paid_id` int(50) DEFAULT NULL,
  `parent_id` int(10) DEFAULT NULL,
  `card_status` varchar(2) DEFAULT NULL COMMENT '[0]=>''D'',[1]=>''A''',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cms_pages`
--

CREATE TABLE `cms_pages` (
  `id` int(10) NOT NULL,
  `page_title` varchar(20) DEFAULT NULL,
  `description` text,
  `status` varchar(2) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cms_pages`
--

INSERT INTO `cms_pages` (`id`, `page_title`, `description`, `status`, `created_at`, `updated_at`) VALUES
(5, 'sdfsdfsda', '<p>sfdsafsdafa</p>', '1', '2019-04-16 12:34:20', '2019-04-16 12:34:20');

-- --------------------------------------------------------

--
-- Table structure for table `commission`
--

CREATE TABLE `commission` (
  `id` int(90) NOT NULL,
  `user_id` int(50) NOT NULL,
  `compv_expired` int(3) DEFAULT NULL COMMENT '[0]=>''N'',[1]=>''Y''',
  `comission_by_userId` int(50) DEFAULT NULL,
  `commission_point` varchar(20) NOT NULL,
  `commission_level` varchar(4) DEFAULT NULL,
  `paid_id` int(10) DEFAULT NULL,
  `total_wallet_point` float DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `commission`
--

INSERT INTO `commission` (`id`, `user_id`, `compv_expired`, `comission_by_userId`, `commission_point`, `commission_level`, `paid_id`, `total_wallet_point`, `created_at`, `updated_at`) VALUES
(1, 11, 0, 11, '50', '1', 26, 20, '2019-05-13 11:46:22', '2019-05-31 10:30:47');

-- --------------------------------------------------------

--
-- Table structure for table `convertion`
--

CREATE TABLE `convertion` (
  `id` int(10) NOT NULL,
  `convertion_title` varchar(5) DEFAULT NULL,
  `convertion_euro` varchar(5) DEFAULT NULL,
  `convertion_pv` varchar(10) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `convertion`
--

INSERT INTO `convertion` (`id`, `convertion_title`, `convertion_euro`, `convertion_pv`, `created_at`, `updated_at`) VALUES
(2, '1', '16', '2', '2019-05-31 07:49:24', '2019-05-31 07:49:24'),
(3, '2', '50', '50', '2019-05-31 07:49:34', '2019-05-31 07:49:44'),
(4, '3', '50', '30', '2019-05-31 07:50:39', '2019-05-31 07:50:39'),
(5, '4', '60', '60', '2019-05-31 07:50:50', '2019-05-31 07:50:50'),
(6, '5', '50', '20', '2019-05-31 07:50:59', '2019-05-31 07:50:59'),
(7, '6', '65', '53', '2019-05-31 07:51:10', '2019-05-31 07:51:10'),
(8, '7', '65', '85', '2019-05-31 07:51:19', '2019-05-31 07:51:19'),
(9, '8', '6', '23', '2019-05-31 07:51:27', '2019-05-31 07:51:27'),
(10, '9', '60', '50', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(11, '10', '40', '30', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(12, '11', '55', '60', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `dealers`
--

CREATE TABLE `dealers` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userName` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referralCode` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telephoneNumber` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postalCode` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_type` int(3) DEFAULT '2' COMMENT '[0]=>''superAdmin'',[1]=>''Admin'',[2]=>''User'',[3]=>''User''',
  `parent_id` int(10) NOT NULL DEFAULT '0' COMMENT '[0]=>''parent''',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `resiaddress` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `region` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `streat` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fcode` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pariva` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_profile_complete` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '[0]=>''N'',[1]=>''Y''',
  `is_deleted` int(2) DEFAULT '0' COMMENT '[0]=>no,[1]=>yes',
  `is_email_verify` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '[0]=>''N'',[1]=>''Y''',
  `status` int(2) DEFAULT '1' COMMENT '[0]=>''deactive'',[1]=>''active''',
  `qr_code` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profileimage` text COLLATE utf8mb4_unicode_ci,
  `business_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `iban` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paypal` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_as` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT 'BK0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `facebook_url` text COLLATE utf8mb4_unicode_ci,
  `twitter_url` text COLLATE utf8mb4_unicode_ci,
  `linkedin_url` text COLLATE utf8mb4_unicode_ci,
  `instagram_url` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `dealers`
--

INSERT INTO `dealers` (`id`, `name`, `userName`, `referralCode`, `telephoneNumber`, `postalCode`, `email`, `password`, `role_type`, `parent_id`, `remember_token`, `dob`, `resiaddress`, `region`, `streat`, `fcode`, `pariva`, `is_profile_complete`, `is_deleted`, `is_email_verify`, `status`, `qr_code`, `profileimage`, `business_name`, `iban`, `bank`, `paypal`, `user_as`, `created_at`, `updated_at`, `facebook_url`, `twitter_url`, `linkedin_url`, `instagram_url`) VALUES
(60, 'test', 'test', 'LTMZAL', '1234567890', '12345', 'er.bobbysharma92@gmail.com', '$2y$10$waAUaDicNoOfXJUPnzQlE.cE4ACJnLvV4ABdWJ0oXTvnRLO0t5Di6', 2, 0, 'xoZZKS5rwL9RkG0ockPTzJVAuwtuE4PnLZriKXZk', NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, '1', 1, '1857903725.png', NULL, NULL, NULL, NULL, NULL, 'BK0', '2019-04-29 20:28:54', '2019-04-29 20:29:25', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `dealer_detail`
--

CREATE TABLE `dealer_detail` (
  `id` int(11) NOT NULL,
  `affiliatese_id` int(11) NOT NULL,
  `category` varchar(255) DEFAULT NULL,
  `sub_category` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dealer_detail`
--

INSERT INTO `dealer_detail` (`id`, `affiliatese_id`, `category`, `sub_category`, `logo`, `updated_at`, `created_at`) VALUES
(1, 43, '1', '2', '1556793922.jpg', '2019-05-08 15:30:17', '2019-05-01 19:23:32'),
(3, 53, '1', '3', NULL, '2019-05-06 21:23:44', '2019-05-06 21:12:45'),
(4, 57, '2', '3', NULL, '2019-05-08 15:20:42', '2019-05-08 15:20:42');

-- --------------------------------------------------------

--
-- Table structure for table `dealer_images`
--

CREATE TABLE `dealer_images` (
  `id` int(11) NOT NULL,
  `affiliatese_id` int(11) DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dealer_images`
--

INSERT INTO `dealer_images` (`id`, `affiliatese_id`, `file`, `updated_at`, `created_at`) VALUES
(12, 43, '15571583162.jpg', '2019-05-06 20:58:36', '2019-05-06 20:58:36'),
(14, 43, '15571583831.jpg', '2019-05-06 20:59:43', '2019-05-06 20:59:43'),
(15, 43, '15571587141.jpg', '2019-05-06 21:05:14', '2019-05-06 21:05:14'),
(16, 53, '15571597531.jpg', '2019-05-06 21:22:33', '2019-05-06 21:22:33'),
(17, 53, '15571598241.jpg', '2019-05-06 21:23:44', '2019-05-06 21:23:44'),
(18, 43, '15573113961.jpg', '2019-05-08 15:29:56', '2019-05-08 15:29:56'),
(19, 43, '15573113962.png', '2019-05-08 15:29:56', '2019-05-08 15:29:56');

-- --------------------------------------------------------

--
-- Table structure for table `dealer_post`
--

CREATE TABLE `dealer_post` (
  `post_id` int(11) NOT NULL,
  `affiliatese_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `iva` varchar(255) DEFAULT NULL,
  `vat_code` varchar(255) DEFAULT NULL,
  `discount_amount` double DEFAULT NULL,
  `category` int(11) DEFAULT NULL,
  `sub_category` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dealer_post`
--

INSERT INTO `dealer_post` (`post_id`, `affiliatese_id`, `title`, `description`, `iva`, `vat_code`, `discount_amount`, `category`, `sub_category`, `updated_at`, `created_at`) VALUES
(1, 43, 'test2', '<p>test1</p>', '213', '13', 25, 1, 8, '2019-05-08 15:29:39', '2019-04-30 18:36:58'),
(8, 53, 'Test8', '<p>Test8</p>', 'Test8', '666', 67, NULL, NULL, '2019-05-06 21:23:18', '2019-05-06 21:12:45'),
(9, 57, '', '', '66', NULL, 10, NULL, NULL, '2019-05-08 15:20:42', '2019-05-08 15:20:42');

-- --------------------------------------------------------

--
-- Table structure for table `elearningdocs`
--

CREATE TABLE `elearningdocs` (
  `id` int(11) NOT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_type` varchar(255) DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `elearningdocs`
--

INSERT INTO `elearningdocs` (`id`, `file_name`, `file_type`, `file`, `updated_at`, `created_at`) VALUES
(15, 'Test', 'image', '1555681225.jpg', '2019-04-19 18:40:25', '2019-04-19 18:40:25'),
(16, 'Test', 'document', '1555681266.pdf', '2019-04-19 18:41:06', '2019-04-19 18:41:06'),
(17, 'Test', 'video', '1555681285.mp4', '2019-04-19 18:41:25', '2019-04-19 18:41:25'),
(18, 'Test', 'document', '1555681300.pdf', '2019-04-19 18:41:40', '2019-04-19 18:41:40'),
(19, 'Test', 'image', '1555681349.jpg', '2019-04-19 18:42:29', '2019-04-19 18:42:29'),
(20, 'Test', 'image', '1555681365.jpg', '2019-04-19 18:42:45', '2019-04-19 18:42:45'),
(21, 'Test', 'image', '1555681381.jpg', '2019-04-19 18:43:01', '2019-04-19 18:43:01'),
(22, 'Test', 'video', '1555681398.mp4', '2019-04-19 18:43:18', '2019-04-19 18:43:18'),
(23, 'Test', 'video', '1555681415.mp4', '2019-04-19 18:43:35', '2019-04-19 18:43:35'),
(24, 'Test', 'document', '1555681425.pdf', '2019-04-19 18:43:45', '2019-04-19 18:43:45'),
(25, 'Test', 'document', '1555681446.pdf', '2019-04-19 18:44:06', '2019-04-19 18:44:06');

-- --------------------------------------------------------

--
-- Table structure for table `e_wallet`
--

CREATE TABLE `e_wallet` (
  `id` int(90) NOT NULL,
  `user_id` int(10) NOT NULL,
  `paid_id` int(10) NOT NULL,
  `amount` varchar(20) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `e_wallet`
--

INSERT INTO `e_wallet` (`id`, `user_id`, `paid_id`, `amount`, `created_at`, `updated_at`) VALUES
(1, 11, 8, '10.00', '2019-04-08 12:04:53', '2019-04-08 12:04:53'),
(2, 14, 9, '5.00', '2019-04-08 12:18:28', '2019-04-08 12:18:28'),
(3, 11, 10, '6.00', '2019-04-09 07:57:09', '2019-04-09 07:57:09'),
(4, 14, 11, '10.00', '2019-04-09 11:29:24', '2019-04-09 11:29:24'),
(6, 11, 13, '5.00', '2019-04-10 11:26:12', '2019-04-10 11:26:12'),
(7, 14, 14, '2.00', '2019-04-11 07:30:03', '2019-04-11 07:30:03'),
(8, 11, 15, '7.00', '2019-04-11 09:03:09', '2019-04-11 09:03:09'),
(9, 14, 16, '4.00', '2019-04-11 13:45:13', '2019-04-11 13:45:13'),
(10, 14, 17, '10.00', '2019-04-11 14:00:48', '2019-04-11 14:00:48'),
(11, 14, 18, '1.00', '2019-04-11 14:37:19', '2019-04-11 14:37:19'),
(12, 11, 19, '100.00', '2019-04-16 10:25:22', '2019-04-16 10:25:22'),
(13, 14, 20, '2.00', '2019-04-16 12:58:24', '2019-04-16 12:58:24'),
(14, 11, 27, '10.00', '2019-05-20 12:54:56', '2019-05-20 12:54:56');

-- --------------------------------------------------------

--
-- Table structure for table `livello_list`
--

CREATE TABLE `livello_list` (
  `id` int(11) NOT NULL,
  `level_name` varchar(250) DEFAULT NULL,
  `level_percentage` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `livello_list`
--

INSERT INTO `livello_list` (`id`, `level_name`, `level_percentage`) VALUES
(1, 'livello 1', 50),
(2, 'livello 2', 25),
(3, 'livello 3', 12),
(4, 'livello 4', 4),
(5, 'livello 5', 2),
(6, 'livello 6', 1),
(7, 'livello 7', 1),
(8, 'livello 8', 1),
(9, 'livello 9', 1),
(10, 'livello 10', 1),
(11, 'livello 11', 1),
(12, 'livello 12', 1),
(13, 'P', 0.5),
(14, 'PT', 1),
(15, 'PE', 1.5);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `minimum_value_point`
--

CREATE TABLE `minimum_value_point` (
  `id` int(10) NOT NULL,
  `step` varchar(20) DEFAULT NULL,
  `point` varchar(20) DEFAULT NULL,
  `level_upgrade_point` int(10) DEFAULT NULL,
  `level_downline` int(10) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `minimum_value_point`
--

INSERT INTO `minimum_value_point` (`id`, `step`, `point`, `level_upgrade_point`, `level_downline`, `created_at`, `updated_at`) VALUES
(1, 'BK0', '15', 0, 5, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 'BK2', '25', 50, 10, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 'BK4', '35', 75, 15, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 'BK6', '50', 100, 20, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 'BK8', '70', 125, 25, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 'BK10', '85', 150, 30, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 'BK12', '100', 175, 35, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(8, 'P', '150', 200, 45, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 'PT', '125', 225, 50, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(10, 'PE', '150', 250, 55, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `not_to` int(11) DEFAULT NULL,
  `not_from` int(11) DEFAULT NULL,
  `message` longtext,
  `type` int(11) NOT NULL DEFAULT '0',
  `role_type` int(11) DEFAULT NULL,
  `is_read` int(2) NOT NULL DEFAULT '0',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `not_to`, `not_from`, `message`, `type`, `role_type`, `is_read`, `updated_at`, `created_at`) VALUES
(3, 11, 15, 'New User Is Register', 1, 2, 1, '2019-06-03 02:33:41', '2019-05-27 07:22:20');

-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--

CREATE TABLE `order_detail` (
  `id` int(10) NOT NULL,
  `product_id` int(20) DEFAULT NULL,
  `checkout_id` int(10) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  `product_name` varchar(100) DEFAULT NULL,
  `product_price` varchar(10) DEFAULT NULL,
  `total_price` varchar(10) DEFAULT NULL,
  `paid_id` int(20) DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_detail`
--

INSERT INTO `order_detail` (`id`, `product_id`, `checkout_id`, `user_id`, `product_name`, `product_price`, `total_price`, `paid_id`, `status`, `created_at`, `updated_at`) VALUES
(26, 3, NULL, 54, 'Test Card 2', '60', '60.00', 26, '1', '2019-05-13 11:46:22', '2019-05-13 11:46:22');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(90) NOT NULL,
  `email` varchar(200) NOT NULL,
  `token` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `payment_history`
--

CREATE TABLE `payment_history` (
  `id` int(90) NOT NULL,
  `txn_id` varchar(200) NOT NULL,
  `user_id` int(90) NOT NULL,
  `userName` varchar(100) NOT NULL,
  `currencyCode` varchar(5) NOT NULL,
  `paidAmount` varchar(100) NOT NULL,
  `status` varchar(20) NOT NULL,
  `payment_level` varchar(20) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment_history`
--

INSERT INTO `payment_history` (`id`, `txn_id`, `user_id`, `userName`, `currencyCode`, `paidAmount`, `status`, `payment_level`, `created_at`, `updated_at`) VALUES
(1, '20K031758H517842T', 43, 'test', 'EUR', '1.35', 'Completed', 'A', '2019-05-03 15:42:36', '2019-05-03 15:42:36'),
(24, '20K031758H517842T', 53, 'sdfsa', 'usd', '10', 'complee', 'A', '2018-02-13 00:00:00', '0000-00-00 00:00:00'),
(26, '5W246602TU557511D', 54, 'Sergio', 'EUR', '60.00', 'Completed', 'C', '2019-05-13 11:46:21', '2019-05-13 11:46:21');

-- --------------------------------------------------------

--
-- Table structure for table `paypal_setting`
--

CREATE TABLE `paypal_setting` (
  `id` int(10) NOT NULL,
  `business_id` varchar(100) NOT NULL,
  `paypal_type` enum('1','2') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT '[1]=>''S'',[2]=>''P''',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paypal_setting`
--

INSERT INTO `paypal_setting` (`id`, `business_id`, `paypal_type`, `created_at`, `updated_at`) VALUES
(1, 'testve@yopmail.com', '1', '2019-04-16 00:00:00', '2019-05-05 19:59:07');

-- --------------------------------------------------------

--
-- Table structure for table `set_reminder`
--

CREATE TABLE `set_reminder` (
  `id` int(10) NOT NULL,
  `reminder_type` int(20) DEFAULT NULL,
  `reminder_date` text,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `set_reminder`
--

INSERT INTO `set_reminder` (`id`, `reminder_type`, `reminder_date`, `created_at`, `updated_at`) VALUES
(7, 1, '[\"20\",\"4\"]', '2019-05-15 13:10:44', '2019-05-16 08:00:12'),
(8, 2, '[\"10\",\"4\",\"20\"]', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `id` int(10) NOT NULL,
  `dr_name` varchar(200) DEFAULT NULL,
  `patent_name` varchar(200) DEFAULT NULL,
  `time` varchar(200) DEFAULT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`id`, `dr_name`, `patent_name`, `time`, `start_date`, `end_date`) VALUES
(0, 'Stefano Scuri', 'lorenzo aranzulla', 'Controllo (10)', '2019-05-23 00:00:00', '2019-05-24 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `upload-card`
--

CREATE TABLE `upload-card` (
  `id` int(10) NOT NULL,
  `title` varchar(200) DEFAULT NULL,
  `image` text,
  `description` text,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `amount` int(10) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `upload-card`
--

INSERT INTO `upload-card` (`id`, `title`, `image`, `description`, `status`, `amount`, `created_at`, `updated_at`) VALUES
(2, 'Test Card', '1556792324.jpg', '<pre>\r\nLorem Ipsum &egrave; semplicemente un testo fittizio dell&#39;industria della stampa e della composizione. Lorem Ipsum &egrave; stato il testo fittizio standard del settore sin dal 1500, quando una stampante sconosciuta ha preso una cambusa di tipo e l&#39;ha codificata per creare un libro esemplificativo di tipo. &Egrave; sopravvissuto non solo a cinque secoli, ma anche al salto nella composizione elettronica, rimanendo sostanzialmente invariato. &Egrave; stato reso popolare negli anni &#39;60 con la pubblicazione di fogli Letraset contenenti brani di Lorem Ipsum e, pi&ugrave; recentemente, con software di desktop publishing come Aldus PageMaker che include versioni di Lorem Ipsum</pre>', '1', 10, '2019-05-01 12:38:08', '2019-05-02 10:18:44'),
(3, 'Test Card 2', '1556792333.jpg', '<pre>\r\nLorem Ipsum &egrave; semplicemente un testo fittizio dell&#39;industria della stampa e della composizione. Lorem Ipsum &egrave; stato il testo fittizio standard del settore sin dal 1500, quando una stampante sconosciuta ha preso una cambusa di tipo e l&#39;ha codificata per creare un libro esemplificativo di tipo. &Egrave; sopravvissuto non solo a cinque secoli, ma anche al salto nella composizione elettronica, rimanendo sostanzialmente invariato. &Egrave; stato reso popolare negli anni &#39;60 con la pubblicazione di fogli Letraset contenenti brani di Lorem Ipsum e, pi&ugrave; recentemente, con software di desktop publishing come Aldus PageMaker che include versioni di Lorem Ipsum.</pre>\r\n\r\n<pre>\r\n\r\n&nbsp;</pre>', '1', 60, '2019-05-01 12:38:50', '2019-05-02 10:18:53'),
(4, 'Test Card 3', '1556792342.jpg', '<pre>\r\nLorem Ipsum &egrave; semplicemente un testo fittizio dell&#39;industria della stampa e della composizione. Lorem Ipsum &egrave; stato il testo fittizio standard del settore sin dal 1500, quando una stampante sconosciuta ha preso una cambusa di tipo e l&#39;ha codificata per creare un libro esemplificativo di tipo. &Egrave; sopravvissuto non solo a cinque secoli, ma anche al salto nella composizione elettronica, rimanendo sostanzialmente invariato. &Egrave; stato reso popolare negli anni &#39;60 con la pubblicazione di fogli Letraset contenenti brani di Lorem Ipsum e, pi&ugrave; recentemente, con software di desktop publishing come Aldus PageMaker che include versioni di Lorem Ipsum.</pre>\r\n\r\n<pre>\r\n\r\n&nbsp;</pre>', '1', 50, '2019-05-01 12:39:03', '2019-05-02 10:19:02'),
(5, 'Test Card 70', '1556792351.jpg', '<pre>\r\nLorem Ipsum &egrave; semplicemente un testo fittizio dell&#39;industria della stampa e della composizione. Lorem Ipsum &egrave; stato il testo fittizio standard del settore sin dal 1500, quando una stampante sconosciuta ha preso una cambusa di tipo e l&#39;ha codificata per creare un libro esemplificativo di tipo. &Egrave; sopravvissuto non solo a cinque secoli, ma anche al salto nella composizione elettronica, rimanendo sostanzialmente invariato. &Egrave; stato reso popolare negli anni &#39;60 con la pubblicazione di fogli Letraset contenenti brani di Lorem Ipsum e, pi&ugrave; recentemente, con software di desktop publishing come Aldus PageMaker che include versioni di Lorem Ipsum.</pre>\r\n\r\n<pre>\r\n\r\n&nbsp;</pre>', '1', 80, '2019-05-01 12:39:16', '2019-05-02 10:19:11');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referralCode` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telephoneNumber` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postalCode` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_type` int(3) DEFAULT '2' COMMENT '[0]=>''superAdmin'',[1]=>''Admin'',[2]=>''Promotor'',[3]=>''User'',[4]=>''Aff''',
  `parent_id` int(10) NOT NULL DEFAULT '0' COMMENT '[0]=>''parent''',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `resiaddress` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `region` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `streat` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fcode` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pariva` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_profile_complete` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '[0]=>''N'',[1]=>''Y''',
  `is_deleted` int(2) DEFAULT '0' COMMENT '[0]=>no,[1]=>yes',
  `is_email_verify` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '[0]=>''N'',[1]=>''Y''',
  `status` int(2) DEFAULT '1' COMMENT '[0]=>''deactive'',[1]=>''active''',
  `qr_code` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profileimage` text COLLATE utf8mb4_unicode_ci,
  `business_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `iban` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paypal` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_as` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT 'BK0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `facebook_url` text COLLATE utf8mb4_unicode_ci,
  `twitter_url` text COLLATE utf8mb4_unicode_ci,
  `linkedin_url` text COLLATE utf8mb4_unicode_ci,
  `instagram_url` text COLLATE utf8mb4_unicode_ci,
  `euro_amount` int(10) DEFAULT NULL,
  `renewal_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `userName`, `referralCode`, `telephoneNumber`, `postalCode`, `email`, `password`, `role_type`, `parent_id`, `remember_token`, `dob`, `resiaddress`, `region`, `streat`, `fcode`, `pariva`, `is_profile_complete`, `is_deleted`, `is_email_verify`, `status`, `qr_code`, `profileimage`, `business_name`, `iban`, `bank`, `paypal`, `user_as`, `created_at`, `updated_at`, `facebook_url`, `twitter_url`, `linkedin_url`, `instagram_url`, `euro_amount`, `renewal_date`) VALUES
(2, 'Admin', NULL, NULL, NULL, NULL, 'admin@gmail.com', '$2y$10$/vPGJnRQUyH2YAW0XUflXenEzj1Xc8j8bUTHUbtujQFgXS26wUaxK', 1, 0, '7VIokDbUiHeXjOdfrrEXsZFaveOmmc4v6kVSl8DBt6LyKyqKBvOroFkkDoLg', NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, '0', 1, NULL, NULL, NULL, NULL, NULL, NULL, 'BK0', '2020-03-27 18:30:00', '2019-03-27 18:30:00', NULL, NULL, NULL, NULL, NULL, NULL),
(11, 'Valentina', 'Finulli', 'N8DQIJ', '8454512032', '110052', 'Finulli@gmail.com', '$2y$10$mSeqluROZkIbpOSpMqZrwu2z7sy5ZSjNUBJjmwNBca88gEaiOj5ti', 2, 0, 'BX7Q8kj2YkFb8MF5yMWCWLofiyCMlee20CSkWK7TZ3BIr1LmwJCgldZuEy5H', '1993-10-12', 'Discesa Gasssssa 10', 'crischan', 'Discesa Gaiola 10', 'd5', '12', '1', 0, '1', 1, '455.png', '1557225129.jpg', 'wertewwww', '84595551200', 'erter', 'mukesh@gmail.com', 'BK4', '2019-03-29 04:47:30', '2019-05-31 06:20:22', 'www.facebook.com', 'http://twitter.com', 'www.linkedin.com', 'www.insta.com', 60, '2020-02-13 00:00:00'),
(14, 'Valeria ', 'Frontini', 'N8DQIK', '845123601203', '120320', 'Frontini@gmail.com', '$2y$10$mSeqluROZkIbpOSpMqZrwu2z7sy5ZSjNUBJjmwNBca88gEaiOj5ti', 2, 11, 'WtgP8XoUsVcKPgFBVogGt8l2eGKANc8GgpZ1wacG0QaKeWD2LRgL5CEDGqvO', NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, '1', 1, '12837.png', NULL, NULL, NULL, NULL, NULL, 'BK0', '2019-03-29 05:11:23', '2019-04-19 20:25:42', 'facebook.com', 'twitter.com', 'linkedin.com', 'instagram.com', NULL, NULL),
(15, 'Laura2', 'Prova', 'N8DQIN', '4578454510', '110052', 'Prova26@gmail.com', '$2y$10$mSeqluROZkIbpOSpMqZrwu2z7sy5ZSjNUBJjmwNBca88gEaiOj5ti', 2, 11, '4JQIxGQD962mzyv0EMgL86UQSudRePMQc7fQG3oFuWY61lDftiuZhr72NfEg', NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, '1', 1, '26140.png', NULL, NULL, NULL, NULL, NULL, 'BK0', '2019-03-29 05:12:26', '2019-04-01 06:48:58', NULL, NULL, NULL, NULL, NULL, NULL),
(19, 'Laura \r\n\r\n', 'Prova', 'N8DQIM', '894561230452', '1106202', 'Prova@gmail.com', '$2y$10$mSeqluROZkIbpOSpMqZrwu2z7sy5ZSjNUBJjmwNBca88gEaiOj5ti', 2, 11, '8RScMWn68bSGYHWdg63hnvprZ954A2whjZTcfnDCEbp7RiW5h7qdUNRh5vwu', NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, '1', 0, '20185.png', NULL, NULL, NULL, NULL, NULL, 'BK2', '2019-04-01 03:33:56', '2019-04-25 19:28:44', NULL, NULL, NULL, NULL, NULL, NULL),
(20, 'Michele ', 'Camisana', 'JJ75U7', '8946565451', '110062', 'Camisana@gmail.com', '$2y$10$mSeqluROZkIbpOSpMqZrwu2z7sy5ZSjNUBJjmwNBca88gEaiOj5ti', 2, 19, 'lMYS6OaSpNVXwTMlRAoSaBtzL4kpk7s0HLbpchibmt5HIYgDfwcGCzdB4rrQ', NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, '1', 1, '9103.png', NULL, NULL, NULL, NULL, NULL, 'BK0', '2019-04-01 08:00:24', '2019-04-01 08:00:24', NULL, NULL, NULL, NULL, NULL, NULL),
(21, 'Luca ', 'Provola', 'IBTPEY', '9846465465', '11052', 'Provola@gmil.com', '$2y$10$mSeqluROZkIbpOSpMqZrwu2z7sy5ZSjNUBJjmwNBca88gEaiOj5ti', 2, 19, '9dyxsqhuz1MA3KiR8ZUksatA0CwXG7JCE5TJFs7C236HLgAkE3TaubvVOUYF', NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, '1', 1, '29984.png', NULL, NULL, NULL, NULL, NULL, 'BK0', '2019-04-01 09:26:55', '2019-04-02 03:27:54', NULL, NULL, NULL, NULL, NULL, NULL),
(23, 'Gianluca ', 'Valli', 'FQ4U6P', '84561230120', '110052', 'Valli@gmail.com', '$2y$10$3A35JYBEjjgc1Qhicpnaje0P7A1HKPBUVffvLKwWT5m2sf6DrgfEm', 2, 21, 'dTigJ6cWBTMascz5y28ITBb9WDUjsipVHpC2DrhKIBmJqFa8ImUcWb633P2S', NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, '1', 1, '1798.png', NULL, NULL, NULL, NULL, NULL, 'BK0', '2019-04-02 01:15:50', '2019-04-02 01:15:50', NULL, NULL, NULL, NULL, NULL, NULL),
(30, 'Mario ', 'Rossi', 'DDUP8Y', '8456123012', '110053', 'Mario98@gmail.com', '$2y$10$kuz/F/bZpsp7O4AtjZxOJuPyC8QnjPBOBWUavutGyTSQRYjpXl9sm', 2, 21, 'GYtBvHzWzoIgMrJxQmOZ4Y4TGHCGLqxZwU10un7PNsHkEEjDauQjBjaQ3pX7', NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, '1', 1, '15395.png', NULL, NULL, NULL, NULL, NULL, 'BK0', '2019-04-02 08:02:07', '2019-04-03 06:24:12', NULL, NULL, NULL, NULL, NULL, NULL),
(33, 'Riccardo Terraneo', 'Ricky', 'VQUDUK', '3401448148', '20121', 'riccardo.t@komete.it', '$2y$10$OO49IwJct3dCKco2eCbul.OJpOXQTqq2e5G/cqP5i6i0wH4UehhpK', 2, 0, 'QwOCqriD26ydN34K0L0EFPqCxXxOD6NIDG58avvo', NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, '0', 1, '338.png', NULL, NULL, NULL, NULL, NULL, 'BK0', '2019-04-05 20:23:59', '2019-04-09 14:11:24', NULL, NULL, NULL, NULL, NULL, NULL),
(34, 'Francesco Quarta', 'quarta', 'KGANHV', '3401448148', '25121', 'valenziari@gmail.com', '$2y$10$.RCB1.m5zkwiApgYMngaDekbsIRJfYd54hf3sQ4aVun7QzsXiZSr2', 2, 0, 'DRytDcq9C48srTiMcKIpjSV6n56sSkJvYXueseaa5IFke1qI9P7z4rPdwJuD', NULL, NULL, NULL, NULL, NULL, NULL, '0', 1, '0', 1, '29422.png', NULL, NULL, NULL, NULL, NULL, 'BK0', '2019-04-05 20:45:23', '2019-04-06 15:26:48', NULL, NULL, NULL, NULL, NULL, NULL),
(38, 'Giuseppina', 'Giuseppina', NULL, '9545120632', '110052', 'Giuseppina@gmail.com', '$2y$10$mSeqluROZkIbpOSpMqZrwu2z7sy5ZSjNUBJjmwNBca88gEaiOj5ti', 3, 0, 'bHobQ5AjaCyz6yOT8zJeB7R5PElj53l6JELIWZgFqj33apcMJ8j6TMQlOonF', NULL, NULL, NULL, NULL, NULL, NULL, '1', 0, '1', 1, NULL, NULL, NULL, NULL, NULL, NULL, 'BK0', '2019-04-25 18:40:40', '2019-04-25 18:40:40', NULL, NULL, NULL, NULL, NULL, NULL),
(39, 'Riccardo', 'De Peppo Cocco', 'Y06UIF', '3400558442', '25062', 'riccardodpc@gmail.com', '$2y$10$u8u86kEyfSqHeCyD0e9Qfeg1epQJkEZuNbVua5eDb3KlFIXt.5hDm', 2, 0, 'D30usX7wjbF85MNxMQ8aXMI8Vn0XxvsUjVwRo005R21tJH4h7zeknEj3s2H3', NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, '1', 1, '1759732654.png', NULL, NULL, NULL, NULL, NULL, 'BK0', '2019-04-27 13:42:14', '2019-04-27 13:42:32', NULL, NULL, NULL, NULL, NULL, NULL),
(43, 'test', 'test', '', '1234567890', '12345', 'er.bobbysharma92@gmail.com', '$2y$10$nv0JScMd69.MW4fJQZ2ca.yhIFomTvLJ3t9lFgYWFotRmYRx5g2K.', 4, 21, 'hbOgoKHzdt2d2qPvy06AQ4INFIF1SiMUpxO0kh17efQM27K6DSZr8RGqvsIF', '2019-05-01', 'test', 'test', '12', '123', '12345', '1', 0, '1', 1, '426164302.png', '1556714734.jpg', '123', '123', '234', '12345678901', 'BK0', '2019-04-30 17:01:33', '2019-05-02 14:20:46', NULL, NULL, NULL, NULL, NULL, NULL),
(50, 'Francesco', 'Gaetarelli', '4JGAKW', '3401448148', '25121', 'fgaetarelli@gmail.com', '$2y$10$OWewigr9UXxXzby3UGAqp.ql4t9bxjxb0AyhEa5u90ehkf6IqqsOe', 2, 0, '7v9eKCrSkKCvwSVof58kpMzSbei2pLz7oLGX28FT', NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, '0', 1, '193355236.png', NULL, NULL, NULL, NULL, NULL, 'BK0', '2019-05-02 15:02:30', '2019-05-15 01:12:36', NULL, NULL, NULL, NULL, NULL, NULL),
(51, 'Francesco', 'Gaetarelli', 'Z60JZD', '3401448148', '25121', 'fgaterelli@gmail.com', '$2y$10$e/UtljS.RnjDBMv/B5UDYeU2a5wDEFEoLh3PzK59bzD0UY1ezil5K', 2, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, '0', 1, NULL, NULL, NULL, NULL, NULL, NULL, 'BK0', '2019-05-02 15:03:43', '2019-05-02 15:03:43', NULL, NULL, NULL, NULL, NULL, NULL),
(53, 'test8', 'test8', '', '1234567890', '12345', 'bobbysharna@virtualemployee.com', '$2y$10$nvg8uFJPYiXcIjgqRltfTeHF.LC3sVl6Kk2EzEujxA3AqqFStwxAi', 4, 23, 'wKiSvOq03b2VG9ls5iozM0pGiYZO4XhV14qQNziSQ4oJFmIhRI68OLheXfb1', '2019-05-06', 'test', 'test', '12', '123', '666', '1', 0, '1', 1, '1938695428.png', '1557159737.jpg', '123', '123', '234', '12345678901', 'BK0', '2019-05-06 21:12:45', '2019-05-09 08:00:56', NULL, NULL, NULL, NULL, NULL, NULL),
(54, 'Sergio', 'Sergio', '', '8459651203', '110065', 'mukeshbisht98@gmail.com', '$2y$10$mSeqluROZkIbpOSpMqZrwu2z7sy5ZSjNUBJjmwNBca88gEaiOj5ti', 3, 11, '8HU0HruCznykEV2iwWmPAz680nX598ULZk3S7UUSnE0Tk6KEReB2Fv7Vth6Z', NULL, NULL, NULL, NULL, NULL, NULL, '1', 0, '1', 1, '26016.png', NULL, NULL, NULL, NULL, NULL, 'BK0', '2019-05-07 15:35:02', '2019-05-13 06:16:22', NULL, NULL, NULL, NULL, NULL, NULL),
(57, 'Lorenzo', 'Lorenzo', '', '1234567890', '12345', 'lorenzo@gmail.com', '$2y$10$T4Mrh1NNqNaxm0tMUetPAOe.QoSYzdOvdjUDrishfhjrpuhmBFt0q', 4, 11, 'mKq7cvrRkbS3mhoPeuqcFwCVAN5mDepJpCNGRGiNZ2lQVcT0fqUOf3BcBFrm', '2019-05-30', 'dfgds', 'dfgdsfgs', 'dfgdsgds', 'dfgfdsgds', '66', '1', 0, '1', 1, '2122787661.png', '1559124640.jpg', 'dfgdsfgds', 'dfgdsfgdsf', 'fdgdsgds', 'dgfdsgsdgd', 'BK0', '2019-05-08 15:20:42', '2019-05-29 04:40:40', NULL, NULL, NULL, NULL, NULL, NULL),
(58, 'Alessandro', 'De Peppo Cocco', 'TQ9QNJ', '3401448148', '25121', 'alessandro.dpc@komete.it', '$2y$10$/AowcoKZQDA/ZMdKiPOsqeEdmwOjvEh9xqR5zlRIAvJgEs.Vkw1Wm', 2, 0, 'zRWAObebaZH7vDEiXDaSL3pc4Le6h1Yv1PLCwXN0ycgI6VwsJ5GArHYgdphE', NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, '1', 1, '266853462.png', NULL, NULL, NULL, NULL, NULL, 'BK0', '2019-05-08 19:24:19', '2019-05-08 19:24:38', NULL, NULL, NULL, NULL, NULL, NULL),
(59, 'Riccardo', 'De Peppo Cocco', 'OBXXV0', '0302180897', '25062', 'rdepeppococco@parmacalcio1913.com', '$2y$10$jeaOsYmTeVllCrpsiDU7U.XXUpwsbu9.l0YkW0Qjf4tAR.rcjkmVW', 2, 54, 'ljIt7x2y6B3Vgnwy64ZIxhp1eWMkleutdTTC5iMn', NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, '0', 1, '1108754481.png', NULL, NULL, NULL, NULL, NULL, 'BK0', '2019-05-08 22:04:22', '2019-05-29 05:14:23', NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_ratings`
--

CREATE TABLE `user_ratings` (
  `id` int(11) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `aff_id` bigint(20) NOT NULL,
  `rate` int(11) NOT NULL,
  `headline` text,
  `review` text,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_ratings`
--

INSERT INTO `user_ratings` (`id`, `user_id`, `aff_id`, `rate`, `headline`, `review`, `updated_at`, `created_at`) VALUES
(3, 54, 43, 3, 'test 2', 'test 2 test 2 test 2 test 2 test 2 test 2 test 2 test 2 test 2 test 2 test 2 test 2 test 2 test 2 test 2 test 2 test 2 test 2 test 2 test 2 test 2 test 2 test 2 test 2 test 2 test 2 test 2 test 2 test 2 test 2', '2019-05-13 07:30:47', '2019-05-13 07:30:47'),
(4, 54, 57, 3, 'test', 'Onta giu ami pei cave osi doni. Cio osavo mie segno dal offro. Trae fina ve mite teco fu cima. Tu salvato credete imagini io fervore di lo stasera. Parlavate era dov sul costretto parentela. Chi bianchezza somigliava guardavamo chi ritornarvi trasognato chiedergli. Testa arabo spero colte via uso tutte. Destinata il principio accomiata io subitaneo ve da lasciarmi. Oppure eccolo guarda osi poi.', '2019-05-13 18:44:01', '2019-05-13 18:41:54');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `affiliate_category`
--
ALTER TABLE `affiliate_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `billing_detail`
--
ALTER TABLE `billing_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bonus_management`
--
ALTER TABLE `bonus_management`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `calendar_management`
--
ALTER TABLE `calendar_management`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `checkout`
--
ALTER TABLE `checkout`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cms_pages`
--
ALTER TABLE `cms_pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `commission`
--
ALTER TABLE `commission`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `convertion`
--
ALTER TABLE `convertion`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dealers`
--
ALTER TABLE `dealers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dealer_detail`
--
ALTER TABLE `dealer_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dealer_images`
--
ALTER TABLE `dealer_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dealer_post`
--
ALTER TABLE `dealer_post`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `elearningdocs`
--
ALTER TABLE `elearningdocs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `e_wallet`
--
ALTER TABLE `e_wallet`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `livello_list`
--
ALTER TABLE `livello_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `minimum_value_point`
--
ALTER TABLE `minimum_value_point`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_detail`
--
ALTER TABLE `order_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_history`
--
ALTER TABLE `payment_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paypal_setting`
--
ALTER TABLE `paypal_setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `set_reminder`
--
ALTER TABLE `set_reminder`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `upload-card`
--
ALTER TABLE `upload-card`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_ratings`
--
ALTER TABLE `user_ratings`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `affiliate_category`
--
ALTER TABLE `affiliate_category`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `billing_detail`
--
ALTER TABLE `billing_detail`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `bonus_management`
--
ALTER TABLE `bonus_management`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `calendar_management`
--
ALTER TABLE `calendar_management`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `checkout`
--
ALTER TABLE `checkout`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cms_pages`
--
ALTER TABLE `cms_pages`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `commission`
--
ALTER TABLE `commission`
  MODIFY `id` int(90) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `convertion`
--
ALTER TABLE `convertion`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `dealers`
--
ALTER TABLE `dealers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `dealer_detail`
--
ALTER TABLE `dealer_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `dealer_images`
--
ALTER TABLE `dealer_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `dealer_post`
--
ALTER TABLE `dealer_post`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `elearningdocs`
--
ALTER TABLE `elearningdocs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `e_wallet`
--
ALTER TABLE `e_wallet`
  MODIFY `id` int(90) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `livello_list`
--
ALTER TABLE `livello_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `minimum_value_point`
--
ALTER TABLE `minimum_value_point`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `order_detail`
--
ALTER TABLE `order_detail`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(90) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment_history`
--
ALTER TABLE `payment_history`
  MODIFY `id` int(90) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `paypal_setting`
--
ALTER TABLE `paypal_setting`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `set_reminder`
--
ALTER TABLE `set_reminder`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `upload-card`
--
ALTER TABLE `upload-card`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `user_ratings`
--
ALTER TABLE `user_ratings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
