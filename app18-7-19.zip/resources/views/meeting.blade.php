@extends('website-layout.header')

@section('content')

<div id="Banner_wrapper" class="bg-parallax category-news cat-meeting" style="background-image:url({{url('website/images/meeting-dark.jpg')}});">
  <div id="Subheader">
   <div class="container">
    <div class="inner_banner_title">
     <h1 class="title">Meeting</h1>
   </div>
 </div>
</div>
</div>
<div id="Content">
  <div id="category-news_section" class="section timeline">
    <div class="container">
      <div class="row">

          
                  <div class="post-item isotope-item clearfix">
                    <div class="date_label"> 17-07-2019 To 17-07-2019</div>

                  
                    <div class="image_frame post-photo-wrapper image">
                      <div class="image_wrapper">
                        <a href="{{url('meeting-detail')}}">
                          <img width="960" height="699" src="{{url('images/news/meeting.jpg')}}" class="img-responsive wp-post-image" alt="">
                        </a>
                      </div>
                    </div>
                  

                    <div class="post-desc-wrapper">
                      <div class="post-desc">
                        <div class="post-title">
                          <h2 class="entry-title"><a href="">Presentazione Bklic a Nardò – Lecce</a></h2>
                        </div>
                        <div class="post-excerpt"><p class="big">Quando la passione incontra la determinazione, la logica conseguenza è il successo</p></div>
                        <div class="post-footer">
                          <div class="post-links"><i class="fa fa-file-text-o"></i> <a href="" class="post-more">Leggi di più</a></div></div>
                        </div>
                      </div>

                    </div>

            

      </div>
    </div>
  </div>
</div>
@endsection