@extends('Affiliatese.dashboard')

@section('content')
<?php
$BusinessEmail= !empty($paypalDetail->business_id)?$paypalDetail->business_id:'';
$paypalUrl=  ($paypalDetail->paypal_type=='1')?'https://www.sandbox.paypal.com/cgi-bin/webscr':'https://www.paypal.com/cgi-bin/webscr';
?>
 <div id="page-wrapper" >
            <div id="page-inner">  
               <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-12">                                    
                                     @if (Session::has('success'))
                                       <div class="alert alert-success alert-block">
                                            <button type="button" class="close" data-dismiss="alert">×</button> 
                                                <strong>{{Session::get('success') }}</strong>
                                        </div>
                                     @endif
									<div class="form-group form-group">
                                    <form role="form" method="post" action="{{$paypalUrl}}"  id="demo-form" data-parsley-validate>
                                         {{ csrf_field() }}          

											<?php // $a= Helper::dealerRenew($userid='43',$amount='10',$paid='50');?>
                                     
										@php 
										    $st = '';
										    if(empty($PaymentHistory->created_at))
												$dateString = $userProfile->created_at;
										    else
												$dateString = $PaymentHistory->created_at;

											
											$dt = new DateTime($dateString);
											$dt->modify('1 years');
										    $deadline = $dt->format('Y-m-d h:i:s');
											$dt1 = new DateTime($deadline);
											$dt1->modify('-27 days');
										    $deadline1 = $dt1->format('Y-m-d h:i:s');
										    $currentdate = date('Y-m-d h:i:s'); 
										@endphp
                                        <table class="table table-bordered" style="border:none;">
												 <thead style="border:none;">
													 <tr style="border:none;"> 
														  <th style="border:none;">Data di iscrizione</th>
														  <th style="border:none;">Scadenza</th>
													 </tr>
												</thead>

												<tbody>
													
													@foreach($cardowners as $Detail)
													 <tr style="border:none;">
													  
													@if($deadline1 >= $currentdate)
													
	                                                @if($userProfile->payment_status == 1)
													@php
														$st = 'enabled';
													@endphp	
													@else
													@php	
														$st = 'disabled';
													@endphp		
													@endif
													
													   <!--<img src="{{url('images/payment.png')}}" class="{{$st}}" title="Fatto" />
													
														<a href="javascript:void(0);" onclick="submitform();" class="{{$st}}" ><img src="{{url('images/extend.png')}}" title="Estensione" /></a>
														<a href="javascript:void(0);" onclick="cancelpayment();" class="{{$st}}"><img src="{{url('images/cancel.png')}}" title="Annulla" /></th></a>-->
													@endif 
													   <td style="border:none;">{{!empty($dateString)? date('m-d-Y',strtotime($dateString)):''}} </td>
													   <td style="border:none;">@if(!empty($deadline)){{date('d-m-Y', strtotime($deadline))}} @endif </td>
													 
													   <!--<td>{{$Detail->iva}}</td>
													   <td>{{$Detail->vat_code}}</td>
													   <td>{{$Detail->discount_amount}}</td>
													   <td>{{$Detail->category}}</td>
													   <td>{{$Detail->sub_category}}</td>-->
																			   
													   
													</tr> 
													<tr style="border:none;">
													<th style="border:none;">rinnova</th>
													</tr> 
													<tr> 
													<td style="border:none;"><span style="font-size: 30px;font-weight: bold;" class="superscript">&euro;</span>
													<span style="font-size: 30px;font-weight: bold;">{{!empty($planGetById)?$planGetById->subscription_price:old('subscription_price')}}</span></td>
													</tr>
													@endforeach

											 </tbody>
										</table> 
										
							
                                         <!--<div class="form-group form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                                              <label for="email" class="col-md-4 control-label">Commento</label>

                                      
                                            <textarea id="comment" type="text" class="form-control" name="comment" value="{{ old('comment') }}" ></textarea>

                                        </div> -->

                                        <input type="hidden" name="business" value="{{$BusinessEmail}}">  
                                        <input type="hidden" name="cmd" value="_xclick"> 
                                        <input type="hidden" name="item_name" value="{{ !empty($userProfile)?$userProfile->name:'' }}">
                                        <input type="hidden" name="item_number" value="{{ !empty($userProfile)?$userProfile->id:'' }}">
                                        <input type="hidden" id="amount" name="amount" value="{{!empty($planGetById)?$planGetById->subscription_price:old('subscription_price')}}">
                                        <input type="hidden" name="currency_code" value="EUR">    
                                        <input type="hidden" name="custom" id="custom" value="">                                        
                                        <input type='hidden' name='cancel_return' value='{{url('paypal/dealer-cancel')}}'>
                                        <input type='hidden' name='return' value='{{url('paypal/dealer-getupgradecommission')}}'> 
                                       <!-- <input type='hidden' name='notify_url' value='{{url('paypal/ipnstatus')}}'> -->
                                        <input type='hidden' name='notify_url' value='https://www.komete.it'>
										
                                        <button type="submit" name="updateprofile" class="btn btn-default">rinnova</button>  

                                    </form>                                  
                                </div>
								<div class="form-group form-group">
								<!--<h4>Elenco dei proprietari di carte</h4>-->
								
								<span style="font-size: 20px;font-weight: bold;color: green;"> Totale utenti card nella tua zona: <span><?php echo count($cardowners); ?></span> </span>
											<?php /* <table class="table table-bordered">
												 <thead>
													 <tr> 
														  <th>S-No</th>
														  <th>Nome</th>
														  <th>E-mail identificativo utente</th>
														  <th>Azione</th> 
													 </tr>
												</thead>

												<tbody>
													<?php $i=1; ?>
													@foreach($cardowners as $Detail)
													 <tr>
													   <th scope="row">{{$i}}</th>
													   <td>{{$Detail->name}}</td>
													   <!--<td>{{$Detail->iva}}</td>
													   <td>{{$Detail->vat_code}}</td>
													   <td>{{$Detail->discount_amount}}</td>
													   <td>{{$Detail->category}}</td>
													   <td>{{$Detail->sub_category}}</td>-->
																			   
													   <td>{{$Detail->email}}</td>
														<td>
														<a href="{{url('viewcardowner/'.$Detail->id)}}"  title="vista"><i class="fa fa-eye" aria-hidden="true"></i></a>
									

														</td>
													</tr> 
													<?php $i++;	?>
													@endforeach

											 </tbody>
								 </table> */ ?>
								</div>
								
                            </div>
                        </div>
                    </div>                   
                </div>
            </div>              
         </div>            
      </div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript">
$(function () {
  $('#demo-form').parsley().on('field:validated', function() {
    var ok = $('.parsley-error').length === 0;
    $('.bs-callout-info').toggleClass('hidden', !ok);
    $('.bs-callout-warning').toggleClass('hidden', ok);
  })

});

function submitform(){
	var st = confirm("Vuoi pagare per estendere?");
	if(st){
		$('#demo-form').submit();
	}else{
		return false;
	}
}

function cancelpayment(){
	var st = confirm("vuoi annullare il pagamento?");
	if(st){
		window.location.replace("cancelpayment");
	}else{
		return false;
	}
}


</script>
<style>
a.disabled {
  pointer-events: none;
  cursor: default;
  filter: grayscale(100%) !important;
}
</style>

@endsection
