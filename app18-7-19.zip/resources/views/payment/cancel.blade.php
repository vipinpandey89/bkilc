@extends('layouts.dashboard')

@section('content')
 <div id="page-wrapper" >
            <div id="page-inner">
                
               
               <div class="row">
                <div class="col-md-12">
                    <!-- Form Elements -->
                    <div class="panel panel-default">
                        
                        <h1>La transazione è stata cancellata.</h1> 
                    
                    </div>                   
                </div>
            </div>              
         </div>
            
    </div>



@endsection
