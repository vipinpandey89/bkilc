@extends('administrator.layout.admin')
@section('title','UserList')
@section('content')
		<div id="page-wrapper">
			<div class="main-page">
				<div class="forms">					
					<div class="form-grids row widget-shadow" data-example-id="basic-forms"> 
						<div class="form-title">
							<h4>Modifica Pagina</h4>
						</div>
						<div class="form-body">
							<form method="post" enctype="multipart/form-data"> 

							<div class="form-group {{ $errors->has('Titolo') ? ' has-error' : '' }}">
								 <label for="exampleInputEmail1">Titolo</label> 
								 <input type="text" class="form-control" name="Titolo" value="{{!empty($getPageDetail)?$getPageDetail->page_title:old('Titolo')}}" id="exampleInputEmail1" placeholder="Titolo">

								    @if ($errors->has('Titolo'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('Titolo') }}</strong>
                                    </span>
                                @endif
							</div>


							
							<div class="form-group {{ $errors->has('editor1') ? ' has-error' : '' }}">
								 <label for="exampleInputEmail1">	Descrizione</label> 
								 <textarea class="form-control" name="editor1" placeholder="Descrizione">{{!empty($getPageDetail)?$getPageDetail->description:old('editor1')}}</textarea>

								   @if ($errors->has('editor1'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('editor1') }}</strong>
                                    </span>
                                @endif

							</div>
								  {{ csrf_field() }}
							

							  <button type="submit" name="addbutton" class="btn btn-default">Salva come</button>
							   </form> 
						</div>
					</div>											
				</div>
			</div>
		</div>
 <script src="https://cdn.ckeditor.com/4.11.4/standard/ckeditor.js"></script>
<script>
	CKEDITOR.replace( 'editor1' );
 </script>	
		@endsection


	