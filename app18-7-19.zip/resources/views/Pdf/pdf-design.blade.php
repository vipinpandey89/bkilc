<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Untitled Document</title>
    <style>
        table {
            font-size: 12px;
        }
    </style>
</head>

<body>
    <table style="width:700px; font-family:Verdana, Geneva, sans-serif;" width="700" cellspacing="0" cellpadding="0" border="0" background="" align="center">
        <tbody>
            <tr>
                <td valign="top" align="left">
                    <table width="100%" cellspacing="0" cellpadding="0" border="0" align="center">
                        <tbody>
                            <tr>
                                <td valign="top">
                                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody>
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td><strong>LETTERA DI INCARICO ALLA VENDITA</strong>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td><strong>DIRETTA A DOMICILIO</strong> (Legge 173/205 e D.Lgs. 114/1998)</td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                                <td valign="top">&nbsp;</td>
                                <td valign="top" align="left">
                                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <div align="right">Bklic s.r.l.</div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div align="right">Via Giammatteo 35, 73100 Lecce</div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div align="right">REA: Le – 324165 - P.I.V.A. /C.F. 04862330752</div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div align="right"><a href="www.bklic.com">www.bklic.com</a>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div align="right">E-mail: incaricati@bklic.it</div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr>
                <td valign="top" align="left">&nbsp;</td>
            </tr>
            <tr>
                <td valign="top" align="left">
                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                        <tbody>
                            <tr>
                                <td>Al Sigr/ Sig.a:</td>
                            </tr>
                            <tr>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>
                                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                                        <tbody>
                                                            <tr>
                                                                <td style="width:50px;">Cognome:</td>
                                                                <td>
                                                                    <input name="textfiled" value="{{$data->userName}}" type="text" style=" border: none; border-bottom-width: 1px; border-bottom-color: #000000; border-bottom-style: solid; outline:none; width:90%;">
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                                <td>
                                                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                                        <tbody>
                                                            <tr>
                                                                <td style="width:50px;">Nome:</td>
                                                                <td>
                                                                    <input name="textfiled" value="{{$data->name}}" type="text" style=" border: none; border-bottom-width: 1px; border-bottom-color: #000000; border-bottom-style: solid; outline:none; width:100%;">
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>
                                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                                        <tbody>
                                                            <tr>
                                                                <td style="width:55px;">Nata/o a:</td>
                                                                <td style="width:500px;">
                                                                    <input name="textfiled2" value="{{date('d-m-Y',strtotime($data->dob))}}" type="text" style=" border: none; border-bottom-width: 1px; border-bottom-color: #000000; border-bottom-style: solid; outline:none; width:100%;">
                                                                </td>
                                                                <!-- <td>( -->
                                                                    <!-- <input name="textfiled2" value="Vipin" type="text" style=" border: none; border-bottom-width: 1px; border-bottom-color: #000000; border-bottom-style: solid; outline:none; width:50%;">)</td> -->
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                                <!-- <td> -->
                                                    <!-- <table width="100%" cellspacing="0" cellpadding="0" border="0"> -->
                                                        <!-- <tbody> -->
                                                            <!-- <tr> -->
                                                                <!-- <td>Il:</td> -->
                                                                <!-- <td> -->
                                                                    <!-- <input name="textfiled2" value="Vipin Kumar" type="text" style=" border: none; border-bottom-width: 1px; border-bottom-color: #000000; border-bottom-style: solid; outline:none; width:100%;"> -->
                                                                <!-- </td> -->
                                                            <!-- </tr> -->
                                                        <!-- </tbody> -->
                                                    <!-- </table> -->
                                                <!-- </td> -->
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>
                                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody>
                                            <tr>
                                                <!-- <td> -->
                                                    <!-- <table width="100%" cellspacing="0" cellpadding="0" border="0"> -->
                                                        <!-- <tbody> -->
                                                            <!-- <tr> -->
                                                                <!-- <td style="width:110px;">Residente a:</td> -->
                                                                <!-- <td style="width: 300px;"> -->
                                                                    <!-- <input name="textfiled" value="Vipin Kumar" type="text" style=" border: none; border-bottom-width: 1px; border-bottom-color: #000000; border-bottom-style: solid; outline:none; width:100%;"> -->
                                                                <!-- </td> -->
                                                                <!-- <td style="width: 102px;">( -->
                                                                    <!-- <input name="textfiled" value="Vipin" type="text" style=" border: none; border-bottom-width: 1px; border-bottom-color: #000000; border-bottom-style: solid; outline:none; width:50%;">)</td> -->
                                                            <!-- </tr> -->
                                                        <!-- </tbody> -->
                                                    <!-- </table> -->
                                                <!-- </td> -->
                                                <td>
                                                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                                        <tbody>
                                                            <tr>
                                                                <td style="width: 60px;">Regione:</td>
                                                                <td>
                                                                    <input name="textfiled" type="text" value="{{$data->region}}" style=" border: none; border-bottom-width: 1px; border-bottom-color: #000000; border-bottom-style: solid; outline:none; width:90%;">
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                                <td>
                                                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                                        <tbody>
                                                            <tr>
                                                                <td style="width: 30px;">Cap:</td>
                                                                <td>
                                                                    <input name="textfiled" type="text" value="{{$data->postalCode}}" style=" border: none; border-bottom-width: 1px; border-bottom-color: #000000; border-bottom-style: solid; outline:none; width:100%;">
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>
                                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                                        <tbody>
                                                            <tr>
                                                                <td style="width:30px;">Via:</td>
                                                                <td>
                                                                    <input name="textfiled" value="{{$data->pariva}}" type="text" style=" border: none; border-bottom-width: 1px; border-bottom-color: #000000; border-bottom-style: solid; outline:none; width:95%;">
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                                <td>
                                                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                                        <tbody>
                                                            <tr>
                                                                <td style="width: 12px;">N°:</td>
                                                                <td>
                                                                    <input name="textfiled" type="text" value="Vipin Kumar" style=" border: none; border-bottom-width: 1px; border-bottom-color: #000000; border-bottom-style: solid; outline:none; width:100%;">
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>
                                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                                        <tbody>
                                                            <tr>
                                                                <td style="width:101px;">Codice Fiscale:</td>
                                                                <td>
                                                                    <input name="textfiled" type="text" value="{{$data->fcode}}" style=" border: none; border-bottom-width: 1px; border-bottom-color: #000000; border-bottom-style: solid; outline:none; width:90%;">
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                                <td>
                                                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                                        <tbody>
                                                            <tr>
                                                                <td style="width:75px;">Part. I.V.A.</td>
                                                                <td>
                                                                    <input name="textfiled" type="text" value="{{$data->pariva}}" style=" border: none; border-bottom-width: 1px; border-bottom-color: #000000; border-bottom-style: solid; outline:none; width:100%;">
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td>&nbsp;</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr>
                <td valign="top" align="left">&nbsp;</td>
            </tr>
            <!-- -->
            <tr>
                <td valign="top" align="left">
                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                        <tbody>
                            <tr>
                                <td width="" valign="top" align="left">Dora in poi (<strong>Promoter</strong>)</td>
                                <td rowspan="20" width="" valign="top" align="left"></td>
                                <td width="" valign="top" align="left">&nbsp;</td>
                            </tr>
                            <tr>
                                <td valign="top" align="left"><strong>PREMESSO</strong>
                                </td>
                                <td valign="top" align="left">&nbsp;</td>
                            </tr>
                            <tr>
                                <td valign="top" align="left">&nbsp;</td>
                                <td valign="top" align="left">&nbsp;</td>
                            </tr>
                            <tr>
                                <td style="width:48%;" valign="top" align="left">
                                    <table style=" text-align:justify;" width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody>
                                            <tr>
                                                <td>- che la nostra società svolge la propria attività nel campo della vendita diretta al domicilio del consumatore finale come contemplato dal D.Lgs. 114/1998 e Legge
                                                    <br>173/2005;</td>
                                            </tr>
                                            <tr>
                                                <td>- che l’attività di promozione e propaganda dei nostri prodotti sarà da Lei effettuata, come da Sue dichiarazioni, in forma assolutamente autonoma e negli orari a Lei congeniali;</td>
                                            </tr>
                                            <tr>
                                                <td>-che, per i motivi di cui sopra, si esclude la possibilità di configurare la presente lettera d’incarico come rapporto di agenzia o rapporto di subordinazione quale dipendente,</td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                                <td style="width:48%;" valign="top" align="left">
                                    <table style=" text-align:justify;" width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody>
                                            <tr>
                                                <td><strong>9.</strong> Con la firma della presente Lei autorizza la nostra società ad emettere, nei termini previsti dalle vigenti leggi e per Suo conto, le fatture o le ricevute provvigionali relative all’attività di Incaricato alle vendite a domicilio. Sarà Sua cura comunicare eventuali anomalie del documento emesso entro 10gg. dalla data di ricevimento, termine oltre il quale tale documento sarà ritenuto valido a tutti gli effetti.</td>
                                            </tr>
                                            <tr>
                                                <td>Con la presente sottoscrizione, inoltre, Lei esonera la nostra società da qualsiasi responsabilità di natura amministrativa e fiscale e dà atto che il servizio di cui sopra
                                                    <br>Le viene reso a titolo gratuito.</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <!-- -->
            <!-- -->
            <tr>
                <td valign="top" align="left">
                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                        <tbody>
                            <tr>
                                <td style="width:48%;" valign="top" align="left">
                                    <table style=" text-align:justify;" width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody>
                                            <tr>
                                                <td><strong>TUTTO CIO’ PREMESSO</strong>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td>Le conferiamo la nomina di INCARICATO ALLE VENDITE A DOMICILIO di cui alle norme della Legge 173 del 17.08.2005 e art.19 del D.Lgs. n.114 del
                                                    <br>31.03.1998.</td>
                                            </tr>
                                            <tr>
                                                <td>Tale incarico sarà disciplinato, oltre che dalle norme che regolano la nostra organizzazione di vendita, dai patti e dalle condizioni di seguito descritte.</td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td><strong>1.</strong> La presente lettera d’incarico è a tempo indeterminato e potrà essere disdettada entrambe le parti in qualsiasi momento senza obbligo di preavviso, senza motivazione e senza diritto ad indennità, compensi o penalità di alcun genere.</td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td><strong>2.</strong> La vendita de nostri prodotti potrà essere da Lei proposta esclusivamente a privati consumatori secondo i metodi e le regole applicate dalla nostra organizzazione. Le è fatto pertanto divieto di assumere ordini da dettaglianti, grossisti o comunque da chi eserciti attività di rivenditore.</td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                                <td rowspan="20" width="" valign="top" align="left"></td>
                                <td style="width:48%;" valign="top" align="left">
                                    <table style=" text-align:justify;" width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody>
                                            <tr>
                                                <td><strong>10.</strong> In qualità di Incaricato alla vendita diretta a domicilio ha diritto di recedere dall’incarico, senza obbligo di motivazione, inviando una e-mail alla società (incaricati@bklic.it), entro dieci (10) giorni lavorativi dalla stipula della presente. In tale caso, sarà Sua cura restituire a Sue spese i beni ed i materiali dimostrativi acquistati o ricevuti in consegna: entro trenta (30) giorni dalla restituzione di tali beni e materiali, la società provvederà a rimborsarLe le somme eventualmente pagate, in modo subordinato all’integrità di quanto restituito.</td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td><strong>11.</strong>In aggiunta al diritto di recesso di cui al precedente comma 10, per tutte le altre ipotesi di cessazione del rapporto con la nostra società e per qualsiasi causa, Le è riconosciuto il diritto di restituzione di tutti i beni e dei materiali dimostrativi e, entro trenta (30) giorni ed in modo subordinato all’integrità di quanto restituito, alla rifusione del prezzo eventualmente pagato per essi, in misura non inferiore al 90% del costo originario.</td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <!-- -->
            <tr>
                <td valign="top" align="left">
                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                        <tbody>
                            <tr>
                                <td style="width:48%;" valign="top" align="left">
                                    <table style=" text-align:justify;" width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody>
                                            <tr>
                                                <td><strong>3.</strong> Per lo svolgimento dell’attività dovrà fare uso esclusivamente dei moduli che la nostra società Le fornirà (nella propria area admin in formato P.D.F.), attenendosi alle clausole e alle condizioni in essi indicate, nonché alle disposizioni del Listino Prezzi in vigore, con assoluto rispetto degli stessi.</td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td><strong>4.</strong> Pur svolgendo materialmente ed in via del tutto principale, in seno alla nostra organizzazione, l’attività di Incaricato alle vendite a domicilio, Le viene concessa la possibilità di coordinare un gruppo di venditori da Lei personalmente reclutati e graditi alla società.</td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                                <td rowspan="20" width="" valign="top" align="left"></td>
                                <td style="width:48%;" valign="top" align="left">
                                    <table style=" text-align:justify;" width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody>
                                            <tr>
                                                <td><strong>12.</strong> In riferimento allo svolgimento dell’attività di vendita a domicilio alconsumatore finale, come contemplato dall’art. 19 comma 6 D.Lgs. 114/1998 e Legge 173/2005, Le è fatto obbligo di esporre il tesserino di riconoscimento rilasciato dalla nostra società. In caso di smarrimento Lei dovrà farne denuncia alle autorità competenti ed inviare copia della stessa alla nostra società.
                                                    <br>In caso di rinuncia o revoca dell’incarico, il tesserino di riconoscimento dovrà essere restituito entro dieci giorni dalla data di cessazione del rapporto.</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <!-- -->
            <tr>
                <td valign="top" align="left">
                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                        <tbody>
                            <tr>
                                <td style="width:48%;" valign="top" align="left">
                                    <table style=" text-align:justify;" width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody>
                                            <tr>
                                                <td><strong>5.</strong> Sugli affari andati a buon fine da Lei segnalati (provvigione dirette) e sugli affari andati a buon fine promossi da venditori da Lei reclutati (provvigione indirette), Le riconosceremo il trattamento provvigionale come da allegati.</td>
                                            </tr>
                                            <tr>
                                                <td>L’incaricato ha preso visione e accetta termini e “Condizioni contrattuali generali per i clienti abituali di Bklic”.</td>
                                            </tr>
                                            <tr>
                                                <td>Nessuna provvigione è dovuta per gli ordini che per qualsiasi ragione non siano giunti a buon fine.</td>
                                            </tr>

                                        </tbody>
                                    </table>
                                </td>
                                <td rowspan="20" width="" valign="top" align="left"></td>
                                <td style="width:48%;" valign="top" align="left">
                                    <table style=" text-align:justify;" width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody>
                                            <tr>
                                                <td><strong>13.</strong> Ai fini dell’iscrizione e del versamento dei contributi alla gestione separata INPS di cui all’art. 2, comma 26, Legge 335/1995, relativamente al corrente anno, Lei dichiara di</td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                                        <tbody>
                                                            <tr>
                                                                <td style="width: 150px;" valign="top">dichiara di</td>
                                                                <td valign="top">
                                                                    <span style="margin-right: 10px;vertical-align: top;border: 1px solid #000;width: 15px;height: 15px;display: inline-block;">
                                                                    </span>
                                                                </td>
                                                                <td>avere</td>
                                                            </tr>
                                                            <tr>
                                                                <td>&nbsp;</td>
                                                                <td valign="top">&nbsp;</td>
                                                                <td>&nbsp;</td>
                                                            </tr>
                                                            <tr>
                                                                <td>&nbsp;</td>
                                                                <td valign="top">
                                                                    <span style="margin-right: 10px;vertical-align: top;border: 1px solid #000;width: 15px;height: 15px;display: inline-block;">
                                                                    </span>
                                                                </td>
                                                                <td>non avere superato un reddito complessivo netti di € 5.000,00 come descritto al precedente comma 7.</td>
                                                            </tr>
                                                            <tr>
                                                                <td>&nbsp;</td>
                                                            </tr>

                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <!-- -->
            <tr>
                <td valign="top" align="left">
                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                        <tbody>
                            <tr>
                                <td style="width:48%;" valign="top" align="left">
                                    <table style=" text-align:justify;" width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody>

                                            <tr>
                                                <td><strong>6.</strong> La nostra società si riserva di organizzare la propria rete di distribuzione su tutto il territorio nazionale nel modo che riterrà più opportuno, mediante vendita diretta, avvalendosi di più collaboratori o incaricati tra loro indipendenti, anche nei luoghi in cui Lei sceglierà autonomamente di operare.</td>
                                            </tr>
                                            <tr>
                                                <td>Per tutte le vendite effettuate da tali collaboratori o incaricati per conto della nostra società, anche nei luoghi suddetti, non Le sarà dovuta alcuna provvigione, compenso o indennità. Ogni ipotesi di esclusiva di zona commerciale è preclusa.</td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                                <td rowspan="20" width="" valign="top" align="left"></td>
                                <td style="width:48%;" valign="top" align="left">
                                    <table style=" text-align:justify;" width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody>

                                            <tr>
                                                <td>
                                                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                                        <tbody>

                                                            <tr>
                                                                <td style="width: 150px;" valign="top">Dichiara inoltre</td>
                                                                <td valign="top">
                                                                    <span style="margin-right: 10px;vertical-align: top;border: 1px solid #000;width: 15px;height: 15px;display: inline-block;">
                                                                    </span>
                                                                </td>
                                                                <td>di avere altra posizione previdenziale obbligatoria aperta</td>
                                                            </tr>
                                                            <tr>
                                                                <td>&nbsp;</td>
                                                                <td valign="top">&nbsp;</td>
                                                                <td>&nbsp;</td>
                                                            </tr>
                                                            <tr>
                                                                <td>&nbsp;</td>
                                                                <td valign="top">
                                                                    <span style="margin-right: 10px;vertical-align: top;border: 1px solid #000;width: 15px;height: 15px;display: inline-block;">
                                                                    </span>
                                                                </td>
                                                                <td>di non avere altra posizione previdenziale obbligatoria aperta</td>
                                                            </tr>
                                                            <tr>
                                                                <td>&nbsp;</td>
                                                                <td valign="top">&nbsp;</td>
                                                                <td>&nbsp;</td>
                                                            </tr>
                                                            <tr>
                                                                <td>&nbsp;</td>
                                                                <td valign="top">
                                                                    <span style="margin-right: 10px;vertical-align: top;border: 1px solid #000;width: 15px;height: 15px;display: inline-block;">
                                                                    </span>
                                                                </td>
                                                                <td>di non avere altra posizione previdenziale obbligatoria aperta</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <!-- -->
            <tr>
                <td valign="top" align="left">
                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                        <tbody>
                            <tr>
                                <td style="width:48%;" valign="top" align="left">
                                    <table style=" text-align:justify;" width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <p><strong>7.</strong> Per quanto imposto dalla legge 173/2005 e R.M. 18/E del 27.01.2006, alsuperamento di € 5.000,00 di provvigioni annuali nette (pari al 78% di € 6.410,00 di provvigioni annuali lorde) derivanti dall’attività d’Incaricato alle vendite dirette di lavoro autonomo occasionale, percepite anche da più committenti, Lei dovrà effettuare l’iscrizione al competente ufficio I.V.A. con il codice 46.19.02 ed iscriversi all’INPS gestione separata di cui alla Legge 335/1998.</p>
                                                    <p>La società si farà carico dei versamenti relativi alle somme delle Sue provvigioni, quale sostituto ai fini IRPEF e sostituto di contributi ai fini INPS.</p>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td><strong>8.</strong> La nostra società non autorizza ad incassare somme da clienti, affiliati, fornitori,inserzionisti e promoter.</td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                                <td rowspan="20" width="" valign="top" align="left"></td>
                                <td style="width:48%;" valign="top" align="left">
                                    <table style=" text-align:justify;" width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody>
                                            <tr>
                                                <td><strong>14.</strong> L’incaricato alle vendite è informato ai sensi del D.Lgs. 196/2003 (Privacy) che:</td>
                                            </tr>
                                            <tr>
                                                <td><strong>a)</strong> i dati forniti per l’accoglimento dell’istruttoria preliminare della richiesta di inizio attività possono essere trattati dalla società per finalità gestionali, statistiche, tutela del credito, commerciali e promozionali, mediante consultazione, elaborazione, raffronto con criteri prefissati ed ogni altra opportuna operazione.</td>
                                            </tr>
                                            <tr>
                                                <td><strong>b)</strong> gli stessi dati, per facilitare i rapporti di comunicazione e scambio di informazioniall’interno della forza vendite, saranno ben visibili in area Admin e, possono essere divulgati a terzi.</td>
                                            </tr>
                                            <tr>
                                                <td><strong>c)</strong> i dati e foto personali, compresi i volumi di fatturati presenti all’azienda, possono essere divulgati a terzi a mezzo di riviste aziendali, pubblicazioni pubblicitarie, classifiche commerciali nell’ambito di riunioni e congressi organizzati per motivazione ed incentivazione del settore commerciale.</td>
                                            </tr>
                                            <tr>
                                                <td><strong>d)</strong> il titolare del trattamento dei dati raccolti è Bklic s.r.l.</td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td><strong>15.</strong> Qualsiasi controversia dovesse sorgere in ordine dell’applicazione della presente lettera, sarà competente il Foro di Lecce.</td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <!-- -->
            <!-- -->
            <tr>
                <td valign="top" align="left">&nbsp;</td>
            </tr>
            <tr>
                <td valign="top" align="left">
                    <table style="border-width:1px; border-color:#000000; border-style:solid; padding: 20px;" width="100%" cellspacing="0" cellpadding="0" border="0">
                        <tbody>
                            <tr>
                                <td>Letto, approvato e sottoscritto</td>
                            </tr>
                            <tr>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>
                                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody>
                                            <tr>
                                                <td>Data</td>
                                                <td>Firma dell’Incaricato alle Vendite</td>
                                                <td>
                                                    <div align="right">Firma del Legale Rappresentante</div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr>
                <td valign="top" align="left">&nbsp;</td>
            </tr>
        </tbody>
    </table>

</body>

</html>